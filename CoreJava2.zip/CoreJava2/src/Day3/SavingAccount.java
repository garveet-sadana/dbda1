package Day3;

public class SavingAccount extends Account{
	private static final double Processing_Fees = 500;
	private int transactionCount;
	
	public SavingAccount(double initialBalance) {
		super(initialBalance, Processing_Fees);
		this.transactionCount = 0;
		
	}
	
	@Override
	public String withdraw(double amount) {
		if(transactionCount >=3) {
			return "Exceeded Maximum transction limit of the day";
		}
		
		if(amount>balance) {
			return "Insufficient balance";
		}
		
		balance -= amount; 
		transactionCount++;
		return "Withdrawal Successful";
	}
	

}
