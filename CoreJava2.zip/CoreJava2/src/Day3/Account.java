package Day3;

abstract class Account {
	protected double balance;
	protected double processingFees;
	
	public Account(double initialBalance, double ProcessingFees) {
		this.balance = initialBalance - processingFees;
		this.processingFees = processingFees;
	}
	
	public double getBalance() {
		return balance;
		
	}
	
	public double getProcessingFees() {
		return processingFees;
	}
	
	public abstract String withdraw(double amount);
	
	

}
