package Day3;

public interface TaxPayer {
	double calculateTax();
}
