package Day3;

public interface Printable {
	
}
