package Day3;

public class SalariedEmployee extends Employee implements TaxPayer{
	
	protected double basic;
	
	public SalariedEmployee(int empid, String name,double basic) {
		
		super(empid,name);
		this.basic = basic; 
	}
	
	@Override
	public double calculateGross() {
		double hra = basic*0.4;
		double da = basic *0.12;
		return basic+hra+da;
	}
	
	public double calculateNet() {
		double gross = calculateGross();
		return gross - gross*0.1;
		
	}
	
	@Override
	public double calculateTax() {
		double gross = calculateGross();
		return gross*0.1;
	}
}
