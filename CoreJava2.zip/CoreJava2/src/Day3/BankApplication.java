package Day3;

public class BankApplication {
	
	public static void main(String args[]) {
		
		Account savingAccount = new SavingAccount(10000);
		System.out.println("Saving Account opened");
		System.out.println("Processing Fees "+savingAccount.getProcessingFees());
		System.out.println("Current Balance "+savingAccount.getBalance());
		
		String result = savingAccount.withdraw(1000);
		System.out.println(result);
		System.out.println("Balance after withdrawal "+savingAccount.getBalance());
		
		Account currentAccount = new CurrentAccount(10000);
		System.out.println("\nCurrent Account opened");
		System.out.println("Processing Fees "+currentAccount.getProcessingFees());
		System.out.println("Current Balance "+currentAccount.getBalance());
		
		result = currentAccount.withdraw(15000);
		System.out.println(result);
		System.out.println("Balance after withdrawal "+currentAccount.getBalance());
		
		LoanAccount loanAccount = new LoanAccount(50000);
		loanAccount.disburseLoan();
		System.out.println("\nLoan Account opened");
		System.out.println("Processing Fess "+loanAccount.getProcessingFees());
		System.out.println("Current Balance "+loanAccount.getBalance());
	}

}
