package Day3;

public class CurrentAccount extends Account {
	private static final double Processing_fees = 1000;
	private boolean hasWithdrawnToday;
	
	public CurrentAccount(double initialBalance) {
		super(initialBalance,Processing_fees);
		this.hasWithdrawnToday = false;
	}
	
	@Override
	
	public String withdraw(double amount) {
		if(hasWithdrawnToday) {
			return "Withdrawal limit for today exceeded";
		}
		
		if(amount>20000) {
			return "Maximum withdrawal limit is 20000 rs";
		}
		
		if(amount>balance) {
			return "Insufficient balance";
		}
		balance -= amount;
		hasWithdrawnToday = true;
		return "Withdrawal Successful";
	}

}
