package Day3;

public class DemoInterface {
	public static void main(String[] args) {
		TaxPayer payer1 = new SalariedEmployee(192, "Shub",20000);
		TaxPayer payer2 = new Manager(192, "Shub",20000,6000);
		TaxPayer payer3 = new Consultant(192,20000);
		
		Payroll payroll= new Payroll();
		payroll.displayTax(payer1);
		payroll.displayTax(payer2);
		payroll.displayTax(payer3);
	}
}
