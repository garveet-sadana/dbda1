package Day3;

public class Payroll {
	
	public void displayTax(TaxPayer payer) {
		System.out.println("Tax for the current month:"+payer.calculateTax());
	}
	
	public void displayGross(Employee e) {
		System.out.println(e);
		System.out.println("Groos Salary for the month : "+e.calculateGross());
	}
	
	public void displayNet(SalariedEmployee e) {
		System.out.println(e);
		System.out.println("Net Salary for the month : "+e.calculateNet());
	}
	
	public static void main(String args[]) {
		Payroll payroll = new Payroll();
		SalariedEmployee se = new SalariedEmployee(333,"aa",45000);
		Manager m= new Manager(123,"mmm",60000,100000);
		
		payroll.displayGross(se);
		payroll.displayGross(m);
		
		Employee [] emp = new Employee[3];
		emp[0] = new SalariedEmployee(666,"PPP",500000);
		emp[1] = new Manager(1234,"KKK",545450,44330);
		emp[2] = new SalesManager(786,"shubham",10000,20000,300000);
		
		for(Employee e: emp) {
			payroll.displayGross(e);
			
		}
		
		// down casting
		
		SalariedEmployee [] semps = new SalariedEmployee[3];
		semps[0] = new SalariedEmployee(56,"saurabh",60000);
		semps[1] = new Manager(37,"Omkar",80000,40000);
		semps[2] = new SalesManager(76,"Sahil",70000,20000,40000);
		
		for(SalariedEmployee semp: semps) {
			payroll.displayNet(semp);
			if(semp instanceof SalesManager) {
				SalesManager ss = (SalesManager) semp;
				ss.showIncentive();
			}
			
		}
		
		}
		
	}


