package Day3;

public class LoanAccount extends Account{
	
	private static final double Processing_fees = 2000;
	private boolean isDisbursed;
	
	public LoanAccount(double initialBalance) {
		super(initialBalance,Processing_fees);
		this.isDisbursed = false;
	}
	
	@Override
	
	public String withdraw(double amount) {
		if(isDisbursed) {
			return "No withdrawal allowed after loan disbursement";
		}
		
		return "Loan account cannot be used for withdrawals";
	}
	
	public void disburseLoan() {
		isDisbursed = true;
	}

}
