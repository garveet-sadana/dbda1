/**
 * 
 */
/**
 * 
 */
module CoreJava {
	requires java.sql;
	requires java.base;
	requires jdk.compiler;
}