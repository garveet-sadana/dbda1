package Day10;

public class ArrayPrint implements Runnable {
	int[] a = { 11, 12, 73, 45, 56, 63, 97, 28, 97, 100};
	Array arr = new Array(a);

	@Override
	public void run() {
		print();
	}

	public synchronized void print() {
		for (int i = 0; i < arr.getArr().length; i++) {
			System.out.println(Thread.currentThread().getName()+arr.getArrayAt(i));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
