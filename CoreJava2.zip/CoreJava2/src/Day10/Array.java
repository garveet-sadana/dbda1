package Day10;

public class Array {
	int[] arr;

	public Array(int[] arr) {
		this.arr = arr;
	}

	public int[] getArr() {
		return arr;
	}

	public int getArrayAt(int n) {
		return arr[n];
	}
}
