package Day10;

public class SynArray {

	public static void main(String[] args) {
		ArrayPrint ap = new ArrayPrint();

		Thread t1 = new Thread(ap);
		Thread t2 = new Thread(ap);

		t1.setName("Array1: ");
		t2.setName("Array2: ");
		t1.start();
		t2.start();

	}

}
