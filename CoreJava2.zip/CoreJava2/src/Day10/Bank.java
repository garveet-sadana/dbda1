package Day10;

public class Bank {

	public static void main(String[] args) {
		MyBal mybal = new MyBal();
		
		Thread dipost = new Thread(new Runnable() {

			@Override
			public void run() {
				for(int i=0; i<5; i++) {
					mybal.setBalance(2000);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});
		
		Thread withdraw = new Thread(new Runnable() {
			@Override
			public void run() {
				for(int i=0; i<5; i++) {
					mybal.getBalance(2000);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});
		
		dipost.start();
		withdraw.start();

	}

}
