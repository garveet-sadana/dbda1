package Day10;

public class WithdrawJob implements Runnable {
	Account acc = new Account(10000);

	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			withdraw(2000);
		}
	}

	public synchronized void withdraw(int amt) {
		if (acc.getBalance() >= amt) {
			System.out.println(Thread.currentThread().getName() + " is ready to withdraw");
			System.out.println(Thread.currentThread().getName() + " is going to sleep");

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			System.out.println(Thread.currentThread().getName() + " wakes up");
			acc.withdraw(amt);
			System.out.println(Thread.currentThread().getName() + " withdraw successfully");
			System.out.println("Balance: " + acc.getBalance()+"\n");
		} else {
			System.out.println(Thread.currentThread().getName() + " doesn't have enough money");
		}
	}

}
