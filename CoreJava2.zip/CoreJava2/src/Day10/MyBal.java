package Day10;

public class MyBal {
	int balance=100;
	boolean hasvalue;
	
	public synchronized void setBalance(int balance) {
		if(hasvalue) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("\nCurrent Balance: "+ this.balance);
		System.out.println("Adding Amount: "+ balance);		
		this.balance += balance;
		System.out.println("Current Balance after Diposite: "+ this.balance);
		hasvalue=true;
		notify();
	}
	
	public synchronized void getBalance(int balance) {
		if(!hasvalue) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Withdraw Amount: "+balance);
		this.balance -= balance;
		System.out.println("Current Balance after withdraw: "+ this.balance);
		hasvalue = false;
		notify();
	}
	

}
