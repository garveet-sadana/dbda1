package Day10;

public class MyQueue {

	int val = 0;
	boolean hasvalue;
	
	public synchronized void setValue(int val) {
		if(hasvalue) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.val=val;
		System.out.println("\nSet Value: "+val);
		hasvalue = true;
		notify();
	}
	
	public synchronized void getValue() {
		if(!hasvalue) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Got value: "+val);
		hasvalue = false;
		notify();
	}
}
