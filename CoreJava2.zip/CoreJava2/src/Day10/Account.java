package Day10;

public class Account {
	int balance;

	public Account(int balance) {
		this.balance = balance;
	}

	public int getBalance() {
		return balance;
	}

	public void withdraw(int amt) {
		balance -= amt;
	}
}
