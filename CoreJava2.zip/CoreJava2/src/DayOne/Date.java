package DayOne;
public class Date{

	private int day;
	private String month;
	private int year;

	Date(){
		this(1,"jan",2001);
	}
	
	Date(int day,String month){
		this(day,month,2001);	
	}
	Date(String month,int year){
		this(1,month,year);	
	}

	Date(int day){
		this(day,"jan",2001);	
	}

	public String getMonth() {
		return month;
	}

	public int getYear() {
		return year;
	}

	public Date(int day,String month,int year)
	{
		this.day=day;
		this.month=month;
		this.year=year;
	}

	public void setDate(int d ,String m, int y){
		day =d;
		month=m;
		year=y;
	}

	public void setMonth(String month){
		this.month = month;	
	}

	public void setDay (int day){
		if(day>0 && day<=31){
			this.day = day;
		}
	}

	public void setYear(int year){
		this.year = year;
	}

	public int getDay(){
		return this.day;
	}

	public void display()
	{
		System.out.println("DATE :" +day +"-"+month+"-"+year);
	}

	@Override
	public String toString() {
		
		return "DATE SAVED :" +day +"-"+month+"-"+year;
	} 
	
	
}


