package DayOne;

import java.util.Arrays;

public class  Practice{

  public static void main(String args[]){
	  


       System.out.println(Arrays.toString(bubbleSort(new int[]{5,4,3,2,1})));
	
}

   public static int[] bubbleSort(int input[])
	{
      
		for(int i=input.length-1;i >=0;i --)
  			{
     				for(int j =0 ; j< i;j ++)
					{
						if(input[j]>input[j+1])
								{
		       	 						int t = input[j];
		         						input[j] = input[j+1];
			 						input[j+1] = t;		
	
								}
 
					}

  			}
		return input;
 	}
   
  public static void factorial(int a) 
  {
	  
  }


}




















