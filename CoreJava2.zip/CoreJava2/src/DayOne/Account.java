package DayOne;

public class Account {
	public static void main(String[] args) {
		Account d=new Account(4567423, "Hai koi nam",65332.564);
		d.showAccountDetails();
		d.Credit(3443);
		d.Credit(-3213);
		d.showAccountDetails();
		
		d.withdraw(-34432);
		d.withdraw(9999999);
		d.withdraw(234);
		d.showAccountDetails();
	}
    
	private int accid;
	private String name;
	private double balance;
	
	private static int intRate;
	
	static {
		System.out.println("In Static Block");
		intRate =7;
	}
	
	public Account(int accid, String name, double balance) {
		this.accid = accid;
		this.name = name;
		this.balance = balance;
	}
	
	public void showInterrestRate()
	{
		System.out.println("CURRENT INTEREST RATE :" +intRate);
	}
	public void withdraw(double amount)
	{
	  if(this.balance< amount || amount <0)
	  {
		  System.out.println("Invalid amount entered! please try again!!!");
	  }
	  else {
		  this.balance=this.balance-amount;
	  }
		
	}
	
	public void Credit(double amount)
	{
		if(amount <0)
		  {
			  System.out.println("Invalid amount entered! please try again!!!");
		  }
		else {
			this.balance+=amount;
		}
		
	}
	
	public void showAccountDetails() {
		System.out.println(this.toString());
	}

	@Override
	public String toString() {
		return "Account [accid=" + accid + ", name=" + name + ", balance=" + balance + "]";
	}

	public int getAccid() {
		return accid;
	}

	public void setAccid(int accid) {
		this.accid = accid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
}
