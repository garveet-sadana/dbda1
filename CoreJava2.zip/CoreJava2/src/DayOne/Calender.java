package DayOne;
/**
 * <h1> sample</h1>
 */
public class Calender{


public static void main(String args[]){
        Date a=new Date(23,"Feb");
        //a.setDate(Integer.parseInt(args[0]),args[1],Integer.parseInt(args[2]));
        //a.display();
        
        a.display();
        System.out.println(a);

}
}
