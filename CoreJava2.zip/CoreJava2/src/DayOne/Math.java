package DayOne;

public class Math {
	
public static void main(String[] args) {
	       
	add(2,3);
	add(2.5f,3);
	add(2,3.5f);
	add(2.3f,3.2f);
	
	add(10,10,10,10,10,10,10);
	
}
	
	//varsArg
    public static void add(int...num) {
       	int i=0;
    	for( int k:num)
    	{
    		i+=k;
    	}
    	System.out.println("Sum is :"+i);
    }
	public static void add(int a ,int b) {
		System.out.println(a+b);
	}
	
	public static void add(float a ,int b) {
		System.out.println(a+b);
	}
	public static void add(int a ,float b) {
		System.out.println(a+b);
	}
	public static void add(float a ,float b) {
		System.out.println(a+b);
	}
	public static void add(int a ,int b,int c) {
		System.out.println(a+b+c);
	}
	public static void add(float a ,float b,float c) {
		System.out.println(a+b+c);
	}
	public static void add(float a ,int b,int c) {
		System.out.println(a+b+c);
	}
	public static void add(int a ,float b,int c) {
		System.out.println(a+b+c);
	}
	public static void add(int a ,int b,float c) {
		System.out.println(a+b+c);
	}
	
}
