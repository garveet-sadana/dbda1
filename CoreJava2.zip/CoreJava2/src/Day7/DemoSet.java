package Day7;

import java.util.*;

public class DemoSet {

	public static void main(String[] args) {
		HashSet<String> set = new HashSet<>();

		set.add("1");
		set.add("2");
		set.add("3");
		set.add("1");

		System.out.println(set);

		set.remove("1");
		System.out.println(set);
		set.add("4");
		set.add("5");
		System.out.println("...........");
		for (String item : set) {
			System.out.println(item.toUpperCase());
		}
		System.out.println("......");
		Iterator<String> it = set.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
//			System.out.println(set.contains("4");

	}

}
