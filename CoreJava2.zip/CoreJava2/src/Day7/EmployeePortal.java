package Day7;

import java.util.*;

public class EmployeePortal {

	public static void main(String[] args) {
		EmployeeCollection e = new EmployeeCollection();
		List<Employee> emplist = e.initializeEmployeeData();

		e.printEmployeeData(emplist);

		System.out.println("Searching Employee: ");
		Employee found = e.getEmployee(emplist, 434);
		System.out.println("Data: " + found);

		List<Employee> emps = new ArrayList<>();
		TreeSet<String> skills1 = new TreeSet<>();
		skills1.add("java");
		skills1.add("python");
		Employee e1 = new Employee(343, "rrr", 75000, skills1);

		e.addEmployee(emplist, e1);
		e.printEmployeeData(emplist);

		System.out.println("Sorting by employee id: ");
		Collections.sort(emplist);
		e.printEmployeeData(emplist);
		int index = Collections.binarySearch(emplist, new Employee(343, null, 0, null));
		System.out.println("Found at index: " + index);

		System.out.println("Sorting by Name: ");
		Collections.sort(emplist, new NameComparator());
		e.printEmployeeData(emplist);
		index = Collections.binarySearch(emplist, new Employee(0, "sss", 0, null), new NameComparator());
		System.out.println("Found at index: " + index);

		System.out.println("Sorting by salary: ");
		Collections.sort(emplist, new SalaryComparator());
		e.printEmployeeData(emplist);

		System.out.println("Filter by java Skill: ");
		ArrayList<Employee> filtered = e.filterList(emplist, "java");
		e.printEmployeeData(emplist);
	}

}
