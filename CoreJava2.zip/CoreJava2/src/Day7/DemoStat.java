package Day7;

public class DemoStat {

	public static void main(String[] args) {
		Double[] sal = {50000.0, 40000.0, 35000.0};
		Stat<Double> dstat = new Stat<>();
		dstat.setArray(sal);
		System.out.println("Average Salary: "+dstat.calculateAverage());

		Integer[] age = {10, 20, 30};
		Stat<Integer> istat = new Stat<>();
		istat.setArray(age);
		System.out.println("Average Age: "+istat.calculateAverage());
	}

}
