package Day7;

public class MyObject <T>{
	T obj;
	public MyObject(T obj) {
		this.obj=obj;
	}
	
	public String getName() {
		return obj.getClass().getName();
	}
	
	public T get() {
		return obj;
	}
	
	public static void main(String[] args) {
		MyObject<Integer> iobj = new MyObject<Integer>(123);
		System.out.println(iobj.getName());
		System.out.println(iobj.get());
		
		MyObject<String> sobj = new MyObject<String>("Abc");
		System.out.println(sobj.getName());
		System.out.println(sobj.get());
		
	}
}
