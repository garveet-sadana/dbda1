package Day4;

import java.util.Objects;
import java.util.ArrayList;
public class Book implements Print, PrintWrite,Cloneable  {
	
	public int isbn;
	public int srno;
	public String title;
	
	public Book(int isbn, int srno, String title, ArrayList<String> author) {
		super();
		this.isbn = isbn;
		this.srno = srno;
		this.title = title;
		this.author = author;
	}
	ArrayList<String> author = new ArrayList<>();
	
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", srno=" + srno + ", title=" + title + ", author=" + author + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(author, isbn, srno, title);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return Objects.equals(author, other.author) && isbn == other.isbn && srno == other.srno
				&& Objects.equals(title, other.title);
	}
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	@Override
	public void print() {
		Print.super.print();
	}
}
