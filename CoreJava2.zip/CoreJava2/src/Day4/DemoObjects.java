package Day4;

import java.util.ArrayList;

public class DemoObjects {

	public static void main(String[] args) throws CloneNotSupportedException {

		ArrayList<String> author = new ArrayList<>();
		author.add("aaa");
		author.add("bbb");

		Book b1 = new Book(113, 111, "abc", author);
		System.out.println(b1.hashCode());
		
		ArrayList<String> copy = new ArrayList<>();
		for(String a : author) {
			copy.add(a);
		}
		

		Book b3 = b1;
		Book b4 = new Book(b1.isbn, b1.srno, b1.title, copy);
		Book b5 = (Book) b1.clone();

		System.out.println("Original    : " + b1);
		b1.isbn = 123;
		b1.author.add("ccc");
		System.out.println("Shallow copy: " + b3);
		System.out.println("Deep Copy   : " + b4);
		System.out.println("By Clone    : " + b5);
	}

}
