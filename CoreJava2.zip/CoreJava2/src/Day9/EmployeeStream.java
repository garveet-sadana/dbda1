package Day9;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EmployeeStream {
	public static List<Employee> initializeEmployeeData() {
		List<Employee> emps = new ArrayList<>();
		TreeSet<String> skills1 = new TreeSet<>();
		skills1.add("java");
		skills1.add("python");
		Employee e1 = new Employee(343, "aaa", "IT", 100000, skills1);

		TreeSet<String> skills2 = new TreeSet<>();
		skills2.add("java");
		skills2.add("javascript");
		Employee e2 = new Employee(657, "adc", "Sales", 80000, skills2);

		TreeSet<String> skills3 = new TreeSet<>();
		skills3.add("c++");
		skills3.add("python");
		Employee e3 = new Employee(434, "sss", "IT", 560000, skills3);

		TreeSet<String> skills4 = new TreeSet<>();
		skills4.add("c++");
		skills4.add("c");
		Employee e4 = new Employee(989, "ttt", "Managment", 600000, skills4);

		TreeSet<String> skills5 = new TreeSet<>();
		skills5.add("c");
		skills5.add("java");
		Employee e5 = new Employee(989, "ttt", "Managment", 600000, skills5);
		emps.add(e1);
		emps.add(e2);
		emps.add(e3);
		emps.add(e4);
		emps.add(e5);
		return emps;
	}

	public static void main(String[] args) {
		List<Employee> emplist = initializeEmployeeData();
		Stream<Employee> stream = emplist.stream();

		Comparator<Employee> byname = Comparator.comparing(Employee::getName);
		System.out.println("Sorting name: ");
		stream.sorted(byname).forEach(System.out::println);

		System.out.println("\nSorting by name in dept:");
		stream = emplist.stream();
		Comparator<Employee> deptname = Comparator.comparing(Employee::getDept).thenComparing(byname);
		stream.sorted(deptname).forEach(System.out::println);

		System.out.println("\nDepartment wise employee list: ");
		stream = emplist.stream();
		stream.collect(Collectors.groupingBy(Employee::getDept)).forEach((k, v) -> System.out.println(k + " : " + v));

		System.out.println("\nDepartment wise total salary: ");
		stream = emplist.stream();
		Map<String, Double> salbydept = stream.collect(Collectors.groupingBy(Employee::getDept, Collectors.summingDouble(Employee::getSalary)));
		salbydept.forEach((k,v) -> System.out.println("Department: "+k+", Total Salary: "+v));
		
		System.out.println("\nAfter Salary increment: ");
		stream = emplist.stream();
		stream.map((emp) -> new Employee(emp.getEmpid(), emp.getName(), emp.getDept(), emp.getSalary()*1.1, emp.getSkills())).forEach(System.out::println);
		
		System.out.println("\nEmployee who know java");
		stream = emplist.stream();
		stream.filter((emp) -> emp.getSkills().contains("java")).forEach(System.out::println);
		
		System.out.print("\nMinimum Salary: ");
		stream = emplist.stream();
		OptionalDouble minsal = stream.mapToDouble(Employee::getSalary).min();
		System.out.println(minsal.getAsDouble());
		
		System.out.print("\nMaximum Salary: ");
		stream = emplist.stream();
		OptionalDouble maxsal = stream.mapToDouble(Employee::getSalary).max();
		System.out.println(maxsal.getAsDouble());

		System.out.print("\nAverage Salary: ");
		stream = emplist.stream();
		OptionalDouble avgsal = stream.mapToDouble(Employee::getSalary).average();
		System.out.println(avgsal.getAsDouble());
	}

}
