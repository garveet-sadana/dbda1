package Day9;

import java.io.OptionalDataException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DemoIntegerStream {

	public static void main(String[] args) {
		Integer[] arr = {20, 40, 10, 90, 50, 60, 30, 80, 70, 100};
		List<Integer> ilist = Arrays.asList(arr);
		
		System.out.println("Odd numbers: ");
		Stream<Integer> stream = ilist.parallelStream();
		stream.filter((n) -> n%2==1).forEach(System.out::println);
		
		System.out.print("\nSorted: ");
		stream = ilist.parallelStream();
		List<Integer> sorted = stream.sorted(Integer::compareTo).collect(Collectors.toList());
		System.out.println(sorted);
		
		System.out.print("\nFindFirst: ");
		stream = ilist.parallelStream();
		Optional<Integer> first = stream.findFirst();
		if(first.isPresent())
			System.out.println(first.get());
		
		System.out.println("\nMultiple by 10:");
		stream = ilist.parallelStream();
		stream.map((n) -> n*10).forEach(System.out::println);
		
		System.out.print("\nParallel Reduce: ");
		stream = ilist.parallelStream();
		long sum = stream.reduce(0, (a,b) -> a+b);
		System.out.println(sum);
		
		System.out.print("\nReduce: ");
		stream = ilist.stream();
		Optional<Integer> total = stream.reduce((a,b) -> a+b);
		System.out.println(total.get());
		
		System.out.print("\nMinimum: ");
		stream = ilist.stream();
		Optional<Integer> min = stream.min(Integer::compareTo);
		if(min.isPresent())
			System.out.println(min.get());
		
		System.out.print("\nMaximum: ");
		stream = ilist.stream();
		Optional<Integer> max = stream.max(Integer::compareTo);
		if(max.isPresent())
			System.out.println(max.get());
		
		System.out.print("\nAverage: ");
		stream = ilist.stream();
		OptionalDouble avg = stream.mapToDouble(Double::valueOf).average();
		if(avg.isPresent())
			System.out.println(avg.getAsDouble());
	}

}
