package Day9;

import java.util.TreeSet;

public class Employee implements Comparable<Employee> {
	private int empid;
	private String name;
	private String dept;
	private double salary;
	TreeSet<String> skills;

	public int getEmpid() {
		return empid;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public TreeSet<String> getSkills() {
		return skills;
	}

	public String getDept() {
		return dept;
	}

	public Employee(int empid, String name, String dept, double salary, TreeSet<String> skills) {
		super();
		this.empid = empid;
		this.name = name;
		this.dept = dept;
		this.salary = salary;
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", dept=" + dept + ", salary=" + salary + ", skills="
				+ skills + "]";
	}

	@Override
	public int compareTo(Employee o) {

		return this.empid - o.empid;
	}
}
