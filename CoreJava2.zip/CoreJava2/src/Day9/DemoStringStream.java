package Day9;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DemoStringStream {

	public static void main(String[] args) {
		String[] arr = {"Red", "orange", "Yellow", "green", "Blue", "indigo", "Violet"};
		List<String> colours = Arrays.asList(arr);

		System.out.println("Upper Case: ");
		List<String> upper = colours.stream().map((str) -> str.toUpperCase()).collect(Collectors.toList());
		System.out.println(upper);
		
		System.out.println("\nLower Case: ");
		List<String> lower = colours.stream().map(String::toLowerCase).collect(Collectors.toList());
		System.out.println(lower);
		
		System.out.println("\nLess then 5 alphabets in ascending order: ");
		List<String> lessthan5 = colours.stream().filter((str) -> str.length()<=5)
				.collect(Collectors.toList());
		System.out.println(lessthan5);
		
		System.out.println("\nLess than m: ");
		List<String> lessthanm = colours.stream().filter((str) -> str.compareToIgnoreCase("m") < 0).collect(Collectors.toList());
		System.out.println(lessthanm);
		
		System.out.println("\nOnly Upper Case in ascending order: ");
		List<String> onlyupper = colours.stream().filter((str) -> str.codePointAt(0) < 97)
				.sorted(String.CASE_INSENSITIVE_ORDER)
				.collect(Collectors.toList());
		System.out.println(onlyupper);

		System.out.println("\nOnly Lower Case in descending order: ");
		List<String> onlylower = colours.stream().filter((str) -> str.codePointAt(0) >= 97)
				.sorted(String.CASE_INSENSITIVE_ORDER.reversed())
				.collect(Collectors.toList());
		System.out.println(onlylower);
	}

}
