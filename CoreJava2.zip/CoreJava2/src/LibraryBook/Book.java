package LibraryBook;

import java.time.LocalDate;

public class Book {
	private int isbn;
	private String title;
	private int price;
	LocalDate issuedate = null;
	LocalDate retdate = null;

	public Book(int isbn, String title, int price, LocalDate string, LocalDate string2) {
		this.isbn = isbn;
		this.title = title;
		this.price = price;
		this.issuedate = string;
		this.retdate = string2;
	}

	public int getIsbn() {
		return isbn;
	}

	public String getTitle() {
		return title;
	}

	public int getPrice() {
		return price;
	}

	public LocalDate getIssuedate() {
		return issuedate;
	}

	public LocalDate getRetdate() {
		return retdate;
	}

}
