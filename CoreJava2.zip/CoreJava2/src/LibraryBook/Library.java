package LibraryBook;

import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Library {
	
	public List<Book> addedBook(){
		List<Book> book = new ArrayList<>();
		LocalDate r = LocalDate.now();
		
		LocalDate i1 = LocalDate.of(2024, 8, 4);
		Book b1 = new Book(2454, "Aaa", 500, i1, r);
		
		LocalDate i2 = LocalDate.of(2024, 8, 5);
		Book b2 = new Book(2671, "Bbb", 600, i2, r);

		LocalDate i3 = LocalDate.of(2024, 8, 10);
		Book b3 = new Book(7600, "Ccc", 200, i3, r);

		LocalDate i4 = LocalDate.of(2024, 7, 4);
		Book b4 = new Book(6654, "Ddd", 650, i4, r);

		LocalDate i5 = LocalDate.of(2024, 7, 25);
		Book b5 = new Book(9924, "Eee", 880, i5, r);

		LocalDate i6 = LocalDate.of(2024, 8, 14);
		Book b6 = new Book(1190, "Fff", 600, i6, r);
		
		book.add(b1);
		book.add(b2);
		book.add(b3);
		book.add(b4);
		book.add(b5);
		book.add(b6);
		return book;
	}
	
	public void calculateFine() {
		Duration d = Duration.between(null, null)
	}
}
