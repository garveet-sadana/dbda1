package Assignment1;

public class CurrentAccount extends Account {
	public CurrentAccount(int accno, String name, String acctype, double balance, int procfee) {
		super(accno, name, acctype, balance, procfee);
	}

	@Override
	public double withdraw(double amt) {
		if (amt > 20000) {
			System.out.println("Transaction limit exceeded");
			return balance;
		}
		if (amt <= balance) {
			balance = super.withdraw(amt);
			System.out.println("Withdraw Successfully!!");
			return balance;
		} else {
			System.out.println("Insufficient Balance");
			return balance;
		}
	}
}
