package Assignment1;

public interface Printable {
	void print();
}
