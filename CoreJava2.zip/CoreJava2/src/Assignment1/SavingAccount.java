package Assignment1;

public class SavingAccount extends Account {
	private int count = 0;

	public SavingAccount(int accno, String name, String acctype, double balance, int procfee) {
		super(accno, name, acctype, balance, procfee);
	}

	@Override
	public double withdraw(double amt) {
		if (count >= 3) {
			System.out.println("Transaction limit exceeded");
			return balance;
		}
		if (amt <= balance) {
			balance = super.withdraw(amt);
			count++;
			System.out.println("Withdraw Successfully!!");
			return balance;
		} else {
			System.out.println("Insufficient Balance");
			return balance;
		}
	}
}
