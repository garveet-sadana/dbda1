package Assignment1;

public class LoanAccount extends Account {
	public LoanAccount(int accno, String name, String acctype, double balance, int procfee) {
		super(accno, name, acctype, balance, procfee);
	}

	@Override
	public double withdraw(double amt) {
		System.out.println("Withdraw not allowed for Loan Account");
		return balance;
	}
}
