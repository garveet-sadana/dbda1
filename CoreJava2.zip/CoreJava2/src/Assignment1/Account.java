package Assignment1;

public abstract class Account implements Printable{
	protected int accno;
	protected String name;
	protected String acctype;
	protected double balance;
	protected int procfee;

	public Account(int accno, String name, String acctype, double balance, int procfee) {
		this.accno = accno;
		this.name = name;
		this.acctype = acctype;
		this.balance = balance;
		this.procfee = procfee;
	}

	public double withdraw(double amount) {
		if (amount > balance) {
			System.out.println("Insufficient Balance");
			return balance;
		}
		balance -= amount;
		return balance;
	}

	public double deposit(double amount) {
		balance += amount;
		return balance;
	}

	public double viewBalance() {
		return balance;
	}

	public int viewProcFee() {
		return procfee;
	}
	
	public void print() {
		System.out.println("Name: "+name+"\nAccount No: "+accno+"\nBalance: "+balance);
	}
}
