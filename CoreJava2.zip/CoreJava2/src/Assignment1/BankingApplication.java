package Assignment1;

import java.util.Scanner;

public class BankingApplication {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Name: ");
		String name = sc.nextLine();
		System.out.print("Select Account type. \n1. for Saving\n2. for Loan\n3. for Current\nEnter your Choice: ");
		int choice = sc.nextInt();
		Account a = null;
		double amt;
		switch (choice) {
		case 1:
			System.out.println("Enter Deposit Amount (minimum 500): ");
			amt = sc.nextDouble();
			if (amt < 500) {
				System.out.println("Deposit amount too low.");
     
			}
			a = new SavingAccount(12345, name, "Saving", amt, 500);
			break;
		case 2:
			System.out.println("Enter Deposit Amount (minimum 2000): ");
			amt = sc.nextDouble();
			if (amt < 2000) {
				System.out.println("Deposit amount too low.");

			}
			a = new LoanAccount(12345, name, "Loan", amt, 2000);
			break;
		case 3:
			System.out.println("Enter Deposit Amount (minimum 1000): ");
			amt = sc.nextDouble();
			if (amt < 1000) {
				System.out.println("Deposit amount too low.");

			}
			a = new CurrentAccount(12345, name, "Current", amt, 1000);
			break;
		default:
			System.out.println("Invalid choice.");

		}
		int c;
		do {
			System.out.println("\n1. See Balance\n2. Withdraw money\n3. See processing fees\n4. Show All Details\n5. Exit\nEnter choice: ");
			c = sc.nextInt();
			switch (c) {
			case 1:
				System.out.println("Balance: " + a.viewBalance());
				break;
			case 2:
				System.out.println("Enter amount to withdraw: ");
				amt = sc.nextDouble();
				a.withdraw(amt);
				break;
			case 3:
				System.out.println("Processing Fee: " + a.viewProcFee());
				break;
			case 4:
				a.print();
				break;
			case 5:
				System.out.println("Exit!");
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (c != 5);
	}
}
