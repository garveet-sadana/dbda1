package Day11;
import java .time.*;
import java.util.stream.Stream;
import java.util.function.Predicate;
public class PracticeDateTime {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now(); 
		LocalDate birth = LocalDate.of(2002, 11, 05);
		
		System.out.println("\n1. Calculate age in no of days, months, years:");
		Period age = birth.until(today);
		System.out.println(age.getDays()+" days, "+age.getMonths()+" months, "+age.getYears()+" years");
		
		System.out.println("\n3. Find out all the months that started on a Sundays in year 2024:");
		Stream<LocalDate> thisyear = LocalDate.of(2024, 1, 1).datesUntil(LocalDate.of(2025, 1, 1));
		Predicate<LocalDate> monthstart = (dt) -> dt.getDayOfMonth()==1;
		Predicate<LocalDate> sun = (dt) -> dt.getDayOfWeek().equals(DayOfWeek.SUNDAY);
		thisyear.filter(monthstart).filter(sun).forEach(System.out::println);
		
		System.out.println("\n4. If we leave Mumbai at 12:00 pm and arrive in London at 4:40pm. How long is the flight:");
		LocalDateTime dt = LocalDateTime.now();
		ZonedDateTime mumbai = LocalDateTime.of(2024, 9, 14, 12, 0).atZone(ZoneId.of("Asia/Kolkata"));
		ZonedDateTime london = LocalDateTime.of(2024, 9, 14, 16, 40).atZone(ZoneId.of("Europe/London"));
		Duration dur = Duration.between(mumbai, london);
		System.out.println(dur.toHours()+":"+dur.toMinutesPart());
		
	}
}
