package Day11;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class DemoLocalTime {

	public static void main(String[] args) {
		LocalTime ctime = LocalTime.now();
		System.out.println(ctime);
		
		LocalTime nextTime = ctime.plusMinutes(14);
		System.out.println(nextTime);
		
		if(ctime.isBefore(nextTime))
			System.out.println("Difference: "+ctime.until(nextTime, ChronoUnit.MINUTES));
		
		System.out.println(ctime.getHour());
		System.out.println(ctime.getMinute());
		System.out.println(ctime.getSecond());
		System.out.println(ctime.getNano());

	}

}
