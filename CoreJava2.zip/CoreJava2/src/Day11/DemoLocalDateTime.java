package Day11;

import java.util.Set;
import java.time.*;

public class DemoLocalDateTime {

	public static void main(String[] args) {
		Set<String> zones = ZoneId.getAvailableZoneIds();
		System.out.println(zones);

		LocalDateTime dt = LocalDateTime.now();
		System.out.println(dt);
		
		ZonedDateTime newyork = ZonedDateTime.of(dt, ZoneId.of("America/New_York"));
		System.out.println(newyork);
		
		Instant nycurrent = newyork.toInstant();
		ZonedDateTime india = nycurrent.atZone(ZoneId.of("Asia/Calcutta"));
		System.out.println(india);
		
		LocalDateTime indialocal = india.toLocalDateTime();
		LocalDateTime nyclocal = newyork.toLocalDateTime();
		
		Duration interval = Duration.between(indialocal, nyclocal);
		System.out.println(interval);
	}

}
