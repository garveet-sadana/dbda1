package Day11;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class DemoLocalDate {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		System.out.println(today);

		LocalDate bday = LocalDate.of(2002, 11, 5);
		Period timetobday = bday.until(today);
		System.out.println("Time from birth: "+timetobday.getYears()+"/"+timetobday.getMonths()+"/"+timetobday.getDays());
	
		LocalDate nextweek = today.plusWeeks(1);
		System.out.println(nextweek);
		
		LocalDate nextmonth = today.plus(1, ChronoUnit.MONTHS);
		System.out.println(nextmonth);
		
		System.out.println(today.getDayOfMonth());
		System.out.println(today.getDayOfWeek());
		System.out.println(today.getMonth());
		System.out.println(today.getMonthValue());
		System.out.println(today.getYear());
		
		 Stream<LocalDate> thisyear = LocalDate.of(2024, 1, 1).datesUntil(LocalDate.of(2025, 1, 1));
		 Predicate<LocalDate> this13th = (dt) -> dt.getDayOfMonth()==13;
		 Predicate<LocalDate> fridays = (dt) -> dt.getDayOfWeek().equals(DayOfWeek.FRIDAY);
		 thisyear.filter(this13th).filter(fridays).forEach(System.out::println);
	}

}
