package Day11;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBCRUOOperations {

	public static void main(String[] args) throws ClassNotFoundException {
		Connection con = null;
		String url = "jdbc:mysql://localhost:3306/mycollege";
		Class.forName("com.mysql.cj.jdbc.Driver");
		String insertrecord = "insert into students values(?, ?, ?, ?, ?);";
		String updaterecords = "update students set marks=? where rollno=?";
		String selectrecords = "select * from students";

		try {
			con = DriverManager.getConnection(url, "root", "dbda");
//			PreparedStatement pst = con.prepareStatement(insertrecord);
//			pst.setInt(1, 12);
//			pst.setString(2, "Shubham");
//			pst.setString(3, "Sawant");
//			pst.setInt(4, 6);
//			pst.setInt(5, 35);

			// Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
			// ResultSet.);

			PreparedStatement pst = con.prepareStatement(updaterecords);
			pst.setInt(1, 39);
			pst.setInt(2, 12);

			int count = pst.executeUpdate();
			System.out.println(count + " row(s) affected");

		} catch (SQLException e) {
			System.out.println(e);
		}

		try {
			con = DriverManager.getConnection(url, "root", "dbda");
			Statement st = con.createStatement();
			ResultSet records = st.executeQuery(selectrecords);

			while (records.next()) {
				System.out.println(records.getInt(1) + ", " + records.getString(2) + ", " + records.getString(3) + ", "
						+ records.getInt(4) + ", " + records.getInt(5));
			}
		} catch (SQLException e) {
			System.out.println(e);
		}

	}

}
