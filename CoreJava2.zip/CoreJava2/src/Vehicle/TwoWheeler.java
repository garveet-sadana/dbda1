package Vehicle;

public class TwoWheeler extends Vehicle {
	
	public TwoWheeler(int regno, String make, String model, int price) {
		super(regno, make, model, price);
	}

	@Override
	public void calculateInsurance() {
		System.out.println("Insurance Amount Two Wheeler: "+ price*0.05);
	}
	

}
