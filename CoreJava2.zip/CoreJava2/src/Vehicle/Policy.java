package Vehicle;

public class Policy {
	
	public void vehInc(Vehicle v) {
		v.calculateInsurance();
	}

	public static void main(String[] args) {
		Policy p = new Policy();
		TwoWheeler tw = new TwoWheeler(145, "Yamaha", "MT15", 180000);
		FourWheeler fw = new FourWheeler(265, "LandRover", "RangeRover", 20000000);
		
		p.vehInc(tw);
		p.vehInc(fw);

	}

}
