package Vehicle;

public abstract class Vehicle {
	protected int regno;
	protected String make;
	protected String model;
	protected int price;
	
	public Vehicle(int regno, String make, String model, int price) {
		this.regno=regno;
		this.make=make;
		this.model=model;
		this.price=price;
	}

	public abstract void calculateInsurance();
}
