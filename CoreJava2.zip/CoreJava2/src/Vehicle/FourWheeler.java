package Vehicle;

public class FourWheeler extends Vehicle {

	public FourWheeler(int regno, String make, String model, int price) {
		super(regno, make, model, price);
	}

	@Override
	public void calculateInsurance() {
		System.out.println("Insurance Amount of Four Wheeler: "+ price*0.1);
		
	}

}
