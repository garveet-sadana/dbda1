package Day12JDBC;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.Arrays;

public class DemoReflection {

	public static void main(String[] args)
			throws ClassNotFoundException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		Student s = new Student();

		Class c = Class.forName("Day12JDBC.Student");

		Field[] fields = c.getDeclaredFields();

		for (Field f : fields) {
			Type type = f.getGenericType();
			System.out.println(type.getTypeName());
			System.out.println(f.getName());
		}

		for (Field f : fields) {
			f.setAccessible(true);
			if (f.getName().equals("rollno"))
				f.setInt(s, 10);
			if (f.getName().equals("name"))
				f.set(s, "abc");
		}
		System.out.println(s);

		Method[] methods = c.getDeclaredMethods();
		for (Method method : methods) {
			System.out.println(method.getName());
			if (method.getName().equals("simpleMethod"))
				method.invoke(s);
			if (method.getName().equals("methodWithParam")) {
				Type[] types = method.getGenericExceptionTypes();
				System.out.println(Arrays.toString(types));
				method.invoke(s, 23, "Raj");
			}
			if (method.getName().equals("privateMethod")) {
				method.setAccessible(true);
				method.invoke(s);
			}
			if (method.getName().equals("staticMethod")) {
				method.setAccessible(true);
				method.invoke(null);
			}
		}
		
		Constructor<Student> [] cons = C.getDeclaredConstructor();
		for (Constructor<Student>
		
	} 
}
