package Day12JDBC;

public class Student {
	private int rollno;
	private String name;
	
	public Student() {
		rollno=1;
		name="aaa";
	}
	
	public Student(int rollno, String name) {
		this.rollno=rollno;
		this.name=name;
	}
	
	public void simpleMethod() {
		System.out.println("This is a simple method");
	}
	
	public static void staticMethod() {
		System.out.println("This is static method");
	}
	
	private void privateMethod() {
		System.out.println("This is private method");
	}
	
	public void methodWithParam(int rollno, String name) {
		System.out.println("Set roll no: "+rollno+", name: "+name);
	}

	@CreatedBy(name="amruta", priority=2)
	
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + "]";
	}
}
