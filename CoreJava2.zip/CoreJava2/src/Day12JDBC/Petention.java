package Day12JDBC;

public @interface Petention {

}
