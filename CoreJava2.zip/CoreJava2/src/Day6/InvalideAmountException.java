package Day6;

public class InvalideAmountException extends Exception {
	public InvalideAmountException(String m) {
		super(m);
	}
}
