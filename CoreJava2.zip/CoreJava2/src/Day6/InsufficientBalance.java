package Day6;

public class InsufficientBalance extends Exception {
	public InsufficientBalance(String m) {
		super(m);
	}
}
