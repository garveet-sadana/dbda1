package Day6;

public class CustomException {
	
	public void convertToUpperCase(String s) throws EmptyStringException {
		if(s.equals("")) {
			throw new EmptyStringException("String is Empty");
		} else {
			System.out.println("Upper case String: "+ s.toUpperCase());
		}
	}

	public static void main(String[] args) {
		CustomException c = new CustomException();
		
		try {
			c.convertToUpperCase("");
		} catch (EmptyStringException e) {
			System.out.println("Error gives: "+e);
		}
		
	}
}