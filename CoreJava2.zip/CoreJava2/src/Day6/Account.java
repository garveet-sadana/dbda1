package Day6;

public class Account {
	int balance;

	public Account(int balance) {
		this.balance = balance;
	}

	public void withdraw(int amt) throws InsufficientBalance {
		if (amt < balance) {
			balance -= amt;
			System.out.println("Withdraw successfully");
		} else {
			throw new InsufficientBalance("Given amount is more than the balance");
		}
	}
	
	public void deposite(int amt) throws InvalideAmountException{
		if(amt>0) {
			balance += amt;
			System.out.println("Deposite successfully");
		}else {
			throw new InvalideAmountException("Amount must be greater than zero");
		}
	}
}
