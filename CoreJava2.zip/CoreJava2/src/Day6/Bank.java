package Day6;

public class Bank {

	public static void main(String[] args) {
		try {
			Account a1 = new Account(1000);
			a1.withdraw(500);
			a1.deposite(0);
		} catch (InsufficientBalance | InvalideAmountException e) {
			System.out.println(e);
		}
	}
}
