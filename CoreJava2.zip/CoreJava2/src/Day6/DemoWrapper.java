package Day6;

public class DemoWrapper {

	public static void main(String[] args) {
		// Before java 1.5
		 int i=2;
		 Integer j = Integer.valueOf(i);
		 int k = j.intValue();
		 // After java 1.5 
		 int x = 20;
		 Integer y = x;
		 int z = y;
		 
		 // String to integer
		 int a = Integer.parseInt("10");
		 Integer b = Integer.valueOf("20");
		 
		 System.out.println(i);
		 System.out.println(j);
		 System.out.println(k);
		 System.out.println(x);
		 System.out.println(y);
		 System.out.println(a);
		 System.out.println(b);
		 System.out.println();
	}

}
