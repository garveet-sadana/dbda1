package Day6;
import java.util.*;
public class DemoArrayList1 {
	public static void main(String[] args) {
		List lst = new ArrayList<>();
		
		lst.add(100);
		lst.add("Test");
		lst.add(12.5f);
		lst.add(true);
		
		System.out.println(lst);
		System.out.println(lst.get(1));
		
		lst.add(100);
		System.out.println(lst);
		
		lst.remove(3);
		System.out.println(lst);
		
		System.out.println("Looping: ");
		for(int i=0; i<lst.size(); i++) {
			System.out.println(lst.get(i));
		}
		
		System.out.println("For each Looping: ");
		for(Object o: lst) {
			System.out.println(o);
		}
		
		System.out.println("Using Iterator: ");
		Iterator it = lst.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
		
		LinkedList a = new LinkedList();
		a.
	}
}
