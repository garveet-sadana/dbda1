package Day6;

public class EmptyStringException extends Exception {
	public EmptyStringException(String message) {
		super(message);
		System.out.println("Empty String Exception");
	}
}
