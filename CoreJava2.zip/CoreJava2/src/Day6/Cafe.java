package Day6;
import java.util.Scanner;
public class Cafe {

	public static void main(String[] args) {
		Coffee[] coffess = Coffee.values();
		int i=1;
		for(Coffee c: coffess) {
			System.out.println(i+". "+c+", Price: "+c.getPrice());
			i++;
		}
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Select a coffee type: ");
		String choice = sc.next();
		
		System.out.println("Enter the Quantity: ");
		int n = sc.nextInt();
		Coffee cof = Coffee.valueOf(choice.toUpperCase());
		switch (cof) {
			case SMALL: 
				System.out.println("Total Bill for Small Coffee: "+ cof.getPrice()*n);
				break;
			case MEDIUM:
				System.out.println("Total Bill for Medium Coffee: "+ cof.getPrice()*n);
				break;
			case LARGE:
				System.out.println("Total Bill for Large Coffee: "+ cof.getPrice()*n);
				break;
		}		
	}

}
