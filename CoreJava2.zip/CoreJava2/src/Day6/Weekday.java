package Day6;

public enum Weekday {

	MONDAY,TUESDAY;
}
