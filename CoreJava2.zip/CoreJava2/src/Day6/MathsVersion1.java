package Day6;

public class MathsVersion1 {

	public static void main(String[] args) {
		try {
			int i= Integer.parseInt(args[0]);
			int j= Integer.parseInt(args[1]);
			int res = i/j;
			System.out.println(res);
		}
		catch (ArithmeticException e) {
			System.out.println("Arithmetic Exception:");
			System.out.println(e);
		}
		catch (NumberFormatException e) {
			System.out.println("Number Format Exception:");
			System.out.println(e);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Array Index Out Of Bounds Exception:");
			System.out.println(e);
		}
		catch (Exception e) {
			System.out.println("Exception:");
			System.out.println(e);
		}
		
		System.out.println("After Exception");

	} 

}
