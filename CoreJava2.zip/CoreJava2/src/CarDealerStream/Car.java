package CarDealerStream;

import java.util.TreeSet;

public class Car {
	private int regno;
	private String make;
	private String model;
	private int man_year;
	private TreeSet<String> colour;
	private double price;

	public Car(int regno, String make, String model, int man_year, TreeSet<String> colour, double price) {
		super();
		this.regno = regno;
		this.make = make;
		this.model = model;
		this.man_year = man_year;
		this.colour = colour;
		this.price = price;
	}

	public TreeSet<String> getColour() {
		return colour;
	}

	public int getRegno() {
		return regno;
	}

	public String getMake() {
		return make;
	}

	public String getModel() {
		return model;
	}

	public int getMan_year() {
		return man_year;
	}

	public double getPrice() {
		return price;
	}

	@Override
	public String toString() {
		return "Car [regno=" + regno + ", make=" + make + ", model=" + model + ", man_year=" + man_year + ", colour="
				+ colour + "Price= " + price + "]";
	}

}
