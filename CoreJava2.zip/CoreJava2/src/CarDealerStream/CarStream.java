package CarDealerStream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import Day9.Employee;

public class CarStream {
	public static List<Car> initialiseCar() {
		List<Car> cl = new ArrayList<>();
		TreeSet<String> c1 = new TreeSet<>();
		c1.add("Blue");
		c1.add("White");
		Car car1 = new Car(123456, "Toyota", "Corolla", 2020, c1, 50000);

		TreeSet<String> c2 = new TreeSet<>();
		c2.add("Red");
		c2.add("Black");
		Car car2 = new Car(789012, "Honda", "Civic", 2018, c2, 60000);

		TreeSet<String> c3 = new TreeSet<>();
		c3.add("Black");
		c3.add("Silver");
		Car car3 = new Car(345678, "Ford", "Mustang", 2023, c3, 70000);

		TreeSet<String> c4 = new TreeSet<>();
		c4.add("Gray");
		c4.add("White");
		Car car4 = new Car(901234, "BMW", "3Series", 2015, c4, 80000);

		TreeSet<String> c5 = new TreeSet<>();
		c5.add("Silver");
		c5.add("Blue");
		Car car5 = new Car(567890, "Tesla", "Model 3", 2022, c5, 90000);

		TreeSet<String> c6 = new TreeSet<>();
		c6.add("white");
		c6.add("Blue");
		Car car6 = new Car(567891, "Tesla", "Model 3", 2023, c6, 45000);

		TreeSet<String> c7 = new TreeSet<>();
		c7.add("pink");
		c7.add("Blue");
		Car car7 = new Car(567892, "Tesla", "Model 3", 2024, c7, 85000);

		cl.add(car1);
		cl.add(car2);
		cl.add(car3);
		cl.add(car4);
		cl.add(car5);
		cl.add(car6);
		cl.add(car7);

		return cl;

	}

	public static void main(String[] args) {

		List<Car> cars = CarStream.initialiseCar();
		Stream<Car> stream = cars.stream();
		System.out.println("\nPrint stock for a specific color and model :\n");
		stream.collect(Collectors.toMap(Car::getColour, Car::getModel))
				.forEach((k, v) -> System.out.println(k + ":" + v));
		System.out.println();
		System.out.println("\nGrouping dat by model :\n");
		cars.stream().collect(Collectors.groupingBy(Car::getModel))
				.forEach((k, v) -> System.out.println(k + " : " + v));
		// Comparator<car> byModel = Comparator.comparing(Car::getModel);
		System.out.println();

		System.out.println("\nCounting no of cars per model :\n");
		cars.stream().collect(Collectors.groupingBy(Car::getModel, Collectors.counting()))
				.forEach((k, v) -> System.out.println("ModelName : " + k + " Stock: " + v));
		System.out.println();

		System.out.println("\nSorting the cars by make in the ascending order of prices :\n");
		Comparator<Car> byprice = Comparator.comparing(Car::getPrice);
		// how to print Bymake because map not allowing duplicates
		cars.stream().sorted(byprice).forEach(System.out::println);
		System.out.println();

		System.out.println("\nMake a list of old stock - cars in stock manufactured before 2020 :\n");
		List<Car> list = new ArrayList<>();
		// this is list shows output in single line so i am using forEach method
		list = cars.stream().filter(n -> n.getMan_year() < 2020).collect(Collectors.toList());
		cars.stream().filter(n -> n.getMan_year() < 2020).collect(Collectors.toList()).forEach(System.out::println);
		;
		System.out.println();

		System.out.println("\nDisplaying most expensive car :\n");
		// Optional<Car> EC = cars.stream().map(Car::getMake,Car::getPrice).max();
		// i want display car manufacture +model+max price
		OptionalDouble ExpCar = cars.stream().mapToDouble(Car::getPrice).max();
		if (ExpCar.isPresent()) {
			System.out.println(ExpCar.getAsDouble());
		}
		
		System.out.println("\nDisplaying least expensive car :\n");
		OptionalDouble ExCar = cars.stream().mapToDouble(Car::getPrice).min();
		if (ExCar.isPresent()) {
			System.out.println(ExCar.getAsDouble());
		}

	}

}
