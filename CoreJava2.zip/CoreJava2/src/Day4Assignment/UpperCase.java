package Day4Assignment;

public class UpperCase {
	String s;
	public void upperCase(String s) {
		this.s = s;
		int count=0;
		
		for(int i=0; i<s.length(); i++) {
			if('A' <= s.charAt(i) && s.charAt(i) <= 'Z') {
				count++;
			}
		}
		
		System.out.println("\nGiven String: "+ s);
		if(count == s.length()) {
			System.out.println("String is in Upper Case");
		} else {
			System.out.println("String is NOT in Upper Case");
		}
	}
}
