package Day4Assignment;

public class Anagram {
	String s1;
	String s2;

	public void checkAnagram(String s1, String s2) {
		this.s1 = s1;
		this.s2 = s2;
		int count = 0;
		if (s1.length() == s2.length()) {
			for (int i = 0; i < s1.length(); i++) {
				for (int j = 0; j < s2.length(); j++) {
					if (s1.charAt(i) == s2.charAt(j)) {
						count++;
					}
				}
			}      
		}
		System.out.println("String one: " + s1);
		System.out.println("String two: " + s2);

		if (count == s1.length()) {
			System.out.println("Strings are Anagram");
		} else {
			System.out.println("Strings are not Anagram");
		}
	}
}
