package Day4Assignment;

public class DemoString {
	public static void main(String[] args) {
		Anagram a = new Anagram();
		a.checkAnagram("shub", "usbh");
		
		Count c = new Count();
		c.countNum("@Raj");
		
		UpperCase uc = new UpperCase();
		uc.upperCase("RAJ");
		uc.upperCase("RaJ");
	}
}
