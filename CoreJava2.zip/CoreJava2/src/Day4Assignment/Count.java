package Day4Assignment;

public class Count {
	String s;

	public void countNum(String s) {
		this.s = s;
		int cu = 0;
		int cl = 0;
		int cs = 0;

		for (int i = 0; i < s.length(); i++) {
			int temp = s.charAt(i);

			if ('A' <= temp && temp <= 'Z') {
				cu++;
			} else if ('a' <= temp && temp <= 'z') {
				cl++;
			} else if ('0' <= temp && temp <= '9') {

			} else {
				cs++;
			}
		}
		
		System.out.println("\nGiven String: "+s+"\nCount of Upper Case: "+cu+"\nCount of Lower Case: "+cl+"\nCount of Special Character: "+cs);
	}
}
