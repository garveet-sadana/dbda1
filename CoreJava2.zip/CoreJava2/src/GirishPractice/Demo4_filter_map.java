package GirishPractice;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Employi{
	int empid;
	String empName;
	int salary;
	public Employi(int empid, String empName, int salary) {
		
		this.empid = empid;
		this.empName = empName;
		this.salary = salary;
	}
	
		
}
public class Demo4_filter_map {
		public static void main(String[] args) {
			List<Employi> employeeList = new ArrayList<Employi>();
			employeeList.add(new Employi(101,"Alex",10000));
			employeeList.add(new Employi(102,"Brian",20000));
			employeeList.add(new Employi(103,"Charles",30000));
			employeeList.add(new Employi(104,"David",40000));
			employeeList.add(new Employi(105,"Edward",50000));
			
			//Combinatiion of filter and mapp
			
			
			List<Integer>employeesalList = employeeList.stream().filter( e->e.salary >20000).map(e->e.salary).collect(Collectors.toList());
			System.out.println(employeesalList);
			
		}
}
