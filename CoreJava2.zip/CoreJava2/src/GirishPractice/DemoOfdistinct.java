package GirishPractice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DemoOfdistinct {
	public static void main(String [] args) {
		List<String>vehicleList = Arrays.asList("bus","bus","bycle","bus","car","car","bike");
		List<String>distinctvehicle = vehicleList.stream().distinct().collect(Collectors.toList());
		System.out.println(distinctvehicle);
		vehicleList.stream().distinct().forEach(value->System.out.println(value));
		
		//count method
		long count = vehicleList.stream().count();
		System.out.println(count);
		
		//limit()
		List<String> limit = vehicleList.stream().distinct().limit(2).collect(Collectors.toList());
		System.out.println(limit);
	}
}
