package GirishPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FilterDemo1 {
		public static void main(String [] args) {
			//ArrayList<Integer>numberList = new ArrayList<Integer>();
//			numbersList.add(10);
//			numbersList.add(15);
//			numbersList.add(20);
//			numbersList.add(25);
//			numbersList.add(30);
//			numbersList.add(35);
			List<Integer>numbersList = Arrays.asList(10,15,20,25,30);
			List <Integer>evenList = new ArrayList<Integer>();
			//without using stream concept
//			for(int n : numberList) {
//				if(n%2==0) {
//					evenList.add(n);
//				}
//			}
//			System.out.println(evenList);
			
			//with Streams
			
//			evenList = numbersList.stream().filter(n->n%2==0).collect(Collectors.toList());
//			System.out.println(evenList);
			
			//numbersList .stream().filter(n->n%2==0).forEach(n->System.out.println(n));
			//we are doing this in shortcut
			numbersList .stream().filter(n->n%2==0).forEach(System.out:: println);
			
			List<String> names = Arrays.asList("Melisandre","Sansa","Jon","Daenerys","Joffery");
			//filtering length of name
			List<String> longnames =  new ArrayList<String>();
			
//			longnames = names.stream().filter((str->str.length()>6 && str.length()<8)).collect(Collectors.toList());
//			System.out.println(longnames);

				names.stream().filter((str->str.length()>6 && str.length()<8)).forEach(str->System.out.println(str));
				names.stream().filter((str->str.length()>6 && str.length()<8)).forEach(System.out::println);
				
				
				List<String> word = Arrays.asList("cup",null,"forest","sky","book",null,"theater");
				//filter null ..ie. removing null
				System.out.println(word);
				List<String> result = new ArrayList<String>();
				result = word.stream().filter(w-> w!= null).collect(Collectors.toList());
				System.out.println(result);
			
				word.stream().filter(s-> s!=null).forEach(System.out::println);
			
			
			
			
			
			
			
			
			
			
		}
}
