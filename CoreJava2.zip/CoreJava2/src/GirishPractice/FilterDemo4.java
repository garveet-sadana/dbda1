package GirishPractice;

import java.util.ArrayList;
import java.util.List;

class Products {
	int id;
	String name;
	double price;
	public Products(int id, String name, double price) {
		
		this.id = id;
		this.name = name;
		this.price = price;
	}
}
	

public class FilterDemo4{
	public static void main(String[] args) {
		List productList = new ArrayList<Products>();
		productList.add(new Products(1,"Hp Laptop",25000));
		productList.add(new Products(2,"dell Laptop",30000));
		productList.add(new Products(3,"Lenovo Laptop",28000));
		productList.add(new Products(4,"Apple Laptop",90000));
		
		//filter object from collections based on price of object
		productList.stream().filter(p-> p.price >25000).forEach(pr->System.out.println(pr.price));
		
		
		
		
		
		
				}
}
