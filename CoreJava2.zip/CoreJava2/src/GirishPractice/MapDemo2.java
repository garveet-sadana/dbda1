package GirishPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class MapDemo2 {
	public static void main(String[] args) {
		List<String> vehicles = Arrays.asList("bus","car","bicycle","flight","train");
		//i want to find the  length of every elements in vehicles and store it into other list
		List<Integer> length = new ArrayList<Integer>();
		length = vehicles.stream().map(ln-> ln.length()).collect(Collectors.toList());
		System.out.println(length);
		vehicles.stream().map(n->n.length()).forEach(System.out::println);
	}
}
