package Song;
import java.util.List;
import java.util.ArrayList;
import java.util.TreeSet;
import java.util.HashMap;
import java.util.Set;

public class SongCollection {
	List<Song> initializeSongsData(){
		List<Song> songs = new ArrayList<>();
		TreeSet<String> artist1 = new TreeSet<>();
		artist1.add("Arijit");
		artist1.add("Anushka");
		Song s1 = new Song(619, "Aeee", artist1, 2016);
		
		TreeSet<String> artist2 = new TreeSet<>();
		artist2.add("Arijit");
		artist2.add("Priti");
		Song s2 = new Song(657, "hasfgi", artist2, 2024);
		
		TreeSet<String> artist3 = new TreeSet<>();
		artist3.add("Shub");
		artist3.add("Girish");
		Song s3 = new Song(281, "aksuy", artist3, 2006);
		
		TreeSet<String> artist4 = new TreeSet<>();
		artist4.add("Sahil");
		artist4.add("Renu");
		Song s4 = new Song(936, "jsieu", artist4, 1996);
		
		TreeSet<String> artist5 = new TreeSet<>();
		artist5.add("Raj");
		artist5.add("Yash");
		Song s5 = new Song(888, "aysfd", artist5, 2024);
		
		songs.add(s1);
		songs.add(s2);
		songs.add(s3);
		songs.add(s4);
		songs.add(s5);
		return songs;
	}
	
	public List<Song> addSong(List<Song> songs, Song sg){
		songs.add(sg);
		return songs;
	}
	
	public Song getSong(List<Song> songs, String title) {
		for(Song song: songs) {
			if(song.getTitle()==title) {
				return song;
			}
		}
		return null;
	}
	
	public void currentYear(List<Song> songs, int y) {
		for(Song song: songs) {
			if(song.getReleaseyear()==y) {
				System.out.println(song);
			}
		}
	}
	
	public void printSongsData(List<Song> songs) {
		for(Song song: songs) {
			System.out.println(song);
		}
	}
	
	public ArrayList<Song> SpecificArtist(List<Song> songs, String art){
		ArrayList<Song> spart = new ArrayList<>();
		for(Song song: songs) {
			if(song.getSetofartists().contains(art)) {
				spart.add(song);
			}
		}
		return spart;
	}
	
	public void createList(List<Song> songs) {
		HashMap<String, Integer> ty = new HashMap<>();
		
		for(Song song: songs) {
			ty.put(song.getTitle(), song.getReleaseyear());
		}
		
		Set<String> keys = ty.keySet();
		for(String key: keys) {
			System.out.println("Title: "+ key+", Release Year: "+ ty.get(key));
		}
	}
}
