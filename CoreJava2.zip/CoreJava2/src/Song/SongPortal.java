package Song;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
public class SongPortal {

	public static void main(String[] args) {
		SongCollection sc = new SongCollection();
		List<Song> songs = sc.initializeSongsData();
		System.out.println("1. Display list of the songs:");
		sc.printSongsData(songs);
		System.out.println("\n-----------------------------------\n");
		
		System.out.println("2. Sorting Song by Title:");
		Collections.sort(songs, new TitleComparator());
		sc.printSongsData(songs);
		System.out.println("\n-----------------------------------\n");
		
		System.out.println("3. Sorting Song by Release Year:");
		Collections.sort(songs, new YearComparator());
		sc.printSongsData(songs);
		System.out.println("\n-----------------------------------\n");

		Song found = sc.getSong(songs, "aksuy");
		System.out.print("4. Search Song by Title: "+found);
		System.out.println("\n-----------------------------------\n");

		System.out.println("5. List of Songs relesed in current year:");
		sc.currentYear(songs, 2024);
		System.out.println("\n-----------------------------------\n");

		System.out.println("6. List of Songs by Specific Artist:");
		ArrayList<Song> spart = sc.SpecificArtist(songs, "Arijit");
		sc.printSongsData(spart);
		System.out.println("\n-----------------------------------\n");

		System.out.println("7. Listing of Song Title and Relese Year:");
		sc.createList(songs);
		
	}

}
