package Song;

import java.util.TreeSet;

public class Song {
	private int serialno;
	private String title;
	TreeSet<String> setofartists;
	private int releaseyear;

	public int getSerialno() {
		return serialno;
	}

	public String getTitle() {
		return title;
	}

	public TreeSet<String> getSetofartists() {
		return setofartists;
	}

	public int getReleaseyear() {
		return releaseyear;
	}

	public Song(int serialno, String title, TreeSet<String> setofartists, int releaseyear) {
		this.serialno = serialno;
		this.title = title;
		this.setofartists = setofartists;
		this.releaseyear = releaseyear;
	}

	@Override
	public String toString() {
		return "Song [serialno=" + serialno + ", title=" + title + ", setofartists=" + setofartists + ", releaseyear="
				+ releaseyear + "]";
	}

}
