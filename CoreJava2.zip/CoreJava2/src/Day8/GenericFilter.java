package Day8;

public interface GenericFilter<T> {
	T apply(T data);
}