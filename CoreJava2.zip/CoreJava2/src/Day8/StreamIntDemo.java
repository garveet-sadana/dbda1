package Day8;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StreamIntDemo {
	public static void main(String[]args) {
		/*
		 *  A stream is closed after performing a terminal operation to obtain a stream call 
		 *  istream = arrays.stream(arr)
		 */
		
		int[] arr = {12, 4, 25, 87, 65, 11, 95, 11, 25};
		
		IntStream istream = Arrays.stream(arr);
		System.out.println("Printing and sorting and removing duplicate:");
		istream = istream.distinct().sorted(); 
		istream.forEach(System.out :: println);
		
		istream = Arrays.stream(arr);
		System.out.println("\nPrinting using list:");
		List<Integer> list = istream.boxed().collect(Collectors.toList());
		System.out.println(list);
		
		istream = Arrays.stream(arr);
		System.out.println("\nCreating a new mapping in double value(n*2):");
		List<Integer> doubleval = istream.map((n) -> n*2).boxed().collect(Collectors.toList());
		System.out.println(doubleval);
		
		istream = Arrays.stream(arr);
		System.out.println("\nFilter the even numbers:");
		List<Integer> even = istream.filter((n) -> n%2==0).boxed().collect(Collectors.toList());
		System.out.println(even);
		
		istream = Arrays.stream(arr);
		System.out.print("\nTotal Count: ");
		long totalitems = istream.count();
		System.out.println(totalitems);
		
		istream = Arrays.stream(arr);
		System.out.print("\nMinimum Value: ");
		OptionalInt min = istream.min();
		if(min.isPresent())
			System.out.println(min.getAsInt());
		
		istream = Arrays.stream(arr);
		System.out.print("\nMaximum Value: ");
		OptionalInt max = istream.max();
		if(max.isPresent())
			System.out.println(max.getAsInt());
		
		istream = Arrays.stream(arr);
		System.out.print("\nAverage Value: ");
		OptionalDouble avg = istream.average();
		if(avg.isPresent())
			System.out.println(avg.getAsDouble());
	}
}
