package Day8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GenericFunction {
	public static <T> T function(GenericFilter<T> filter, T n) {
		return filter.apply(n);
	}

	public static <T> List<T> operateOnData(Function<T> func, List<T> lst) {
		List<T> mapped = new ArrayList<>();
		for (T item : lst) {
			mapped.add(func.apply(item));
		}
		return mapped;
	}

	public static void main(String[] args) {
		Integer squaredValue = function((Integer n) -> n * n, 5);
		System.out.println(squaredValue);

		String[] greetings = { "hi", "hello", "good morning" };
		List<String> lst = Arrays.asList(greetings);
		List<String> upper = operateOnData((s) -> s.toUpperCase(), lst);
		System.out.println(upper);

		Integer[] arr = { 1, 2, 3, 5 };
		List<Integer> mylist = Arrays.asList(arr);
		List<Integer> cubes = operateOnData((n) -> n * n * n, mylist);
		System.out.println(cubes);

	}
}
