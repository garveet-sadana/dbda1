package Day8;

public interface StringFunction {
	String apply(String str);
}
