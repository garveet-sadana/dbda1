package Day8;

public class StringLambda {

	public static void main(String[] args) {
		StringFunction upperCase = (str) -> str.toUpperCase();
		String result = upperCase.apply("raj");
		System.out.println(result);
		
		StringFunction reverseString = (str) -> {
			StringBuffer st = new StringBuffer();
			for(int i=str.length()-1; i>=0; i--) {
				st.append(str.charAt(i));
			}
			return st.toString();
		};
		
		String result1 = reverseString.apply("raj");
		System.out.println(result1);
	}

}
