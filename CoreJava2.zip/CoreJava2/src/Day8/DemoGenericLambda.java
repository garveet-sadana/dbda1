package Day8;

public interface DemoGenericLambda {
	public static void main(String[] args) {
		Function<Integer> square = (n) -> n * n;
		System.out.println(square.apply(12));

		Function<String> substring = (str) -> str.substring(5);
		System.out.println(substring.apply("java is an OOP language"));

	}

}
