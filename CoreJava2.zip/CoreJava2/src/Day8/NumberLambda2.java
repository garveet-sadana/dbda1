package Day8;

import java.util.*;

public class NumberLambda2 {
	public static boolean operateOnNumber(NumberFilter filter, int n) {
		return filter.test(n);
	}

	public static String operateOnString(StringFunction filter, String str) {
		return filter.apply(str);
	}

	public static ArrayList<Integer> operateOnNumber(NumberFilter filter, List<Integer> lst) {
		ArrayList<Integer> filtered = new ArrayList<>();
		for (Integer n : lst) {
			if (filter.test(n)) {
				filtered.add(n);
			}
		}
		return filtered;
	}

	public static boolean isPrime(int n) {
		for (int i = 2; i < n; i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}
	
	public static String reverseString(String str) {
		StringBuffer sb = new StringBuffer();
		for(int i=str.length()-1; i>=0; i--) {
			sb.append(str.charAt(i));
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		boolean ismultiple = operateOnNumber((n) -> n%5==0, 10);
		System.out.println(ismultiple);
		
		Integer[] arr = {123, 40, 57, 90};
		List<Integer> mylist = Arrays.asList(arr);
		
		List<Integer> multipleoffive = operateOnNumber((n) -> n%5==0, mylist);
		System.out.println(multipleoffive);
		
		boolean result = operateOnNumber(NumberLambda2 :: isPrime, 7);
		System.out.println(result);
		
		String reverse = operateOnString(NumberLambda2 :: reverseString, "raj");
		System.out.println(reverse); 
		
		
	}

}
