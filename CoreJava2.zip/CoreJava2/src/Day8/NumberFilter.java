package Day8;

public interface NumberFilter {
	boolean test(int n);
}
