package Day8;

public interface Function<T> {
	T apply(T data);
}
