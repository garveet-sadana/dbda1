package CarAssignment3;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CarStream {
	public static List<Car> initializeCar() {
		List<Car> carlist = new ArrayList<>();
		TreeSet<String> c1 = new TreeSet<>();
		c1.add("White");
		c1.add("Black");
		Car car1 = new Car(13423, "BMW", "X3", 2020, c1, 7000000);

		TreeSet<String> c2 = new TreeSet<>();
		c2.add("White");
		c2.add("Black");
		Car car2 = new Car(65387, "Maruti Suzuki", "Swift", 2020, c2, 1100000);

		TreeSet<String> c3 = new TreeSet<>();
		c3.add("White");
		c3.add("Black");
		Car car3 = new Car(10928, "Tata", "Nexon", 2019, c3, 1500000);

		TreeSet<String> c4 = new TreeSet<>();
		c4.add("White");
		c4.add("Black");
		Car car4 = new Car(87965, "BMW", "X7", 2017, c4, 7000000);

		TreeSet<String> c5 = new TreeSet<>();
		c5.add("Gray");
		c5.add("Red");
		Car car5 = new Car(77826, "Maruti Suzuki", "Swift", 2023, c5, 1600000);

		TreeSet<String> c6 = new TreeSet<>();
		c6.add("White");
		c6.add("Black");
		Car car6 = new Car(54602, "BMW", "X7", 2023, c6, 12000000);

		TreeSet<String> c7 = new TreeSet<>();
		c7.add("White");
		c7.add("Black");
		Car car7 = new Car(29856, "Tata", "Nexon", 2021, c7, 1700000);

		TreeSet<String> c8 = new TreeSet<>();
		c8.add("White");
		c8.add("Black");
		Car car8 = new Car(64871, "Hyundai", "Creta", 2022, c8, 1800000);

		carlist.add(car1);
		carlist.add(car2);
		carlist.add(car3);
		carlist.add(car4);
		carlist.add(car5);
		carlist.add(car6);
		carlist.add(car7);
		carlist.add(car8);

		return carlist;
	}

	public static void main(String[] args) {
		List<Car> cars = CarStream.initializeCar();
		Stream<Car> stream = cars.stream();

		System.out.println("1. Print stock for a specific model and color: ");
		stream.filter((n) -> n.getcolor().contains("Black") && n.getModel().contains("X7")).forEach(System.out::println);

		stream = cars.stream();
		System.out.println("\n2. Group the data by model: ");
		stream.collect(Collectors.groupingBy(Car::getModel)).forEach((k, v) -> System.out.println(k + ": " + v));

		System.out.println("\n3. Count no of car per model: ");
		stream = cars.stream();
		stream.collect(Collectors.groupingBy(Car::getModel, Collectors.counting()))
				.forEach((k, v) -> System.out.println(k + ": " + v));

		System.out.println("\n4. Sort the cars by make 'BMW' in the ascending order of prices");
		stream = cars.stream();
		stream.filter((n) -> n.getMake()=="BMW").sorted(Comparator.comparing(Car::getPrice)).forEach(System.out::println);
                                                                                                                        

		System.out.println("\n5. Make a list of old stok cars in stock manufactured before 2020: ");
		stream = cars.stream();
		stream.filter((n) -> n.getMan_year() < 2020).forEach(System.out::println);

		System.out.println("\n6. Display the least expensive car in the stock:");
		stream = cars.stream();
		OptionalInt min = stream.mapToInt(Car::getPrice).min();
		if (min.isPresent())
			cars.stream().filter((n) -> n.getPrice() == min.getAsInt()).forEach(System.out::println);

		System.out.println("\n7. Display the most expensive car in the stock:");
		stream = cars.stream();
		OptionalInt max = stream.mapToInt(Car::getPrice).max();
		if (min.isPresent())
			cars.stream().filter((n) -> n.getPrice() == max.getAsInt()).forEach(System.out::println);
	}
}
