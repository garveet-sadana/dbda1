package CarAssignment3;

import java.util.TreeSet;

public class Car {
	private int regno;
	private String make;
	private String model;
	private int man_year;
	TreeSet<String> color;
	private int price;

	public Car(int regno, String make, String model, int man_year, TreeSet<String> color, int price) {
		this.regno = regno;
		this.make = make;
		this.model = model;
		this.man_year = man_year;
		this.color = color;
		this.price = price;
	}

	public int getRegno() {
		return regno;
	}

	public String getMake() {
		return make;
	}

	public String getModel() {
		return model;
	}

	public int getMan_year() {
		return man_year;
	}

	public TreeSet<String> getcolor() {
		return color;
	}

	public int getPrice() {
		return price;
	}

	@Override
	public String toString() {
		return "Car [regno=" + regno + ", make=" + make + ", model=" + model + ", man_year=" + man_year + ", color="
				+ color + ", price= " + price + "]";
	}

}
