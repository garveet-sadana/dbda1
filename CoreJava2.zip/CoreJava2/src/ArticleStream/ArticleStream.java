package ArticleStream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ArticleStream {
	public static List<Article> initializeArticle() {
		List<Article> art = new ArrayList<>();
		TreeSet<String> cat1 = new TreeSet<>();
		cat1.add("Healthcare");
		cat1.add("COVID");
		cat1.add("Public Health");
		Article a1 = new Article(24, "COVID-19: A Global Pandemic", 2020, 1000000, cat1);

		TreeSet<String> cat2 = new TreeSet<>();
		cat2.add("Healthcare");
		cat2.add("Pediatrics");
		cat2.add("Nutrition");
		Article a2 = new Article(4, "Children's Health and Nutrition", 2018, 500, cat2);

		TreeSet<String> cat3 = new TreeSet<>();
		cat3.add("Healthcare");
		cat3.add("Environmental ");
		Article a3 = new Article(56, "Climate Change and Its Impact on Health", 2023, 750000, cat3);

		TreeSet<String> cat4 = new TreeSet<>();
		cat4.add("Healthcare");
		cat4.add("COVID");
		cat4.add("Public Health");
		Article a4 = new Article(24, "COVID-19: A Global Pandemic", 2023, 2000000, cat4);

		TreeSet<String> cat5 = new TreeSet<>();
		cat5.add("COVID");
		cat5.add("Public Health");
		Article a5 = new Article(67, "The Future of Healthcare Technology", 2022, 3000, cat5);

		TreeSet<String> cat6 = new TreeSet<>();
		cat6.add("Healthcare");
		cat6.add("Public Health");
		Article a6 = new Article(98, "Climate Change and Its Impact on Health", 2023, 33000, cat6);

		TreeSet<String> cat7 = new TreeSet<>();
		cat7.add("Healthcare");
		cat7.add("COVID");
		Article a7 = new Article(55, "COVID-19: A Global Pandemic", 2010, 850000, cat7);

		art.add(a1);
		art.add(a2);
		art.add(a3);
		art.add(a4);
		art.add(a5);
		art.add(a6);
		art.add(a7);

		return art;
	}

	public static void main(String[] args) {
		List<Article> art = ArticleStream.initializeArticle();
		Stream<Article> stream = art.stream();

		System.out.println("1.List all the articles that ware created in year 2023");
		stream.filter((n) -> n.getYearofpub() == 2023).forEach(System.out::println);

		System.out.println("\n2. List all article by subject: ");
		stream = art.stream();
		stream.collect(Collectors.groupingBy(Article::getSubject)).forEach((k, v) -> System.out.println(k + ": " + v));

		System.out.println("\n3. Count the articles by Subject: ");
		stream = art.stream();
		stream.collect(Collectors.groupingBy(Article::getSubject, Collectors.counting()))
				.forEach((k, v) -> System.out.println(k + ": " + v));

		System.out.println("\n4. List the articles that got more than 10k views: ");
		stream = art.stream();
		stream.filter((n) -> n.getNoofview() >= 10000).forEach(System.out::println);

		System.out.println("\n5. Print the top 5 trending articles: ");
		stream = art.stream();
		Comparator<Article> bynum = Comparator.comparing(Article::getNoofview);
		stream.sorted(bynum.reversed()).limit(5).forEach(System.out::println);
	}

}
