package ArticleStream;

import java.util.TreeSet;

public class Article {
	private int srno;
	private String subject;
	private int yearofpub;
	private int noofview;
	TreeSet<String> category;

	public Article(int srno, String subject, int yearofpub, int noofview, TreeSet<String> category) {
		this.srno = srno;
		this.subject = subject;
		this.yearofpub = yearofpub;
		this.noofview = noofview;
		this.category = category;
	}

	public int getSrno() {
		return srno;
	}

	public String getSubject() {
		return subject;
	}

	public int getYearofpub() {
		return yearofpub;
	}

	public int getNoofview() {
		return noofview;
	}

	@Override
	public String toString() {
		return "Article [srno=" + srno + ", subject=" + subject + ", yearofpub=" + yearofpub + ", noofview=" + noofview
				+ ", category=" + category + "]";
	}

}
