package ShubA1;

public class Storage implements DB, File{
	public void storeObjToDB() {
		
	}
	public void storeObjToFile();
	
	}
}
