package ShubA1;

public  class SavingAccount extends Account{
	private int count=0;
	
	
	public SavingAccount(int accid, String name, double balance) {
		
		super(accid,name,balance);
		
	}

	public void withdraw(int amount) {
		balance = balance - amount;
		
		
	}
	public void Opening() {
		System.out.println("To open saving account we require rs : 500");
	}
}
