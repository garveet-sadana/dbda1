package ShubA1;

public abstract class Account {
	 public int accid;
	 public String name;
	 public double balance;
	
	  
	 public Account(int accid, String name, double balance) {
		 this.accid=accid;
		 this.name=name;
		 this.balance=balance;
		 
	 }
	 public abstract void withdraw(int amount);
	 
	 public void viewBalance() {
		 System.out.println("Balance="+balance);
		 
	 }
	 

}
