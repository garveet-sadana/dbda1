package ShubA1;

public interface Print {
	void print();
	

}


