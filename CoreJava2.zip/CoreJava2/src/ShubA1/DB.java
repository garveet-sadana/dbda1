package ShubA1;

public interface DB {
	public void storeObjToDB();
}
