package ShubA1;

public class Current extends Account {
	int trans =1;

}
