package DemoShape;

public abstract class Shape {
	public String name;
	
	public Shape(String name) {
		this.name=name;
	}
	public void displayName() {
		System.out.println("Shape Name: "+name);
	}
	public abstract void calculateArea();
}
