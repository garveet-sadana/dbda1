package DemoShape;

public class Circle extends Shape{
	double r;

	public Circle(double r) {
		super("Circle");
		this.r=r;
	}

	@Override
	public void calculateArea() {
		double area = 3.142 * r * r;
		System.out.println("Area of Circle: "+area);
	}

}
