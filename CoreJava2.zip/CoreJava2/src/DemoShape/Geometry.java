package DemoShape;

public class Geometry {
	
	public void displayName(Shape s) {
		s.displayName();
	}
	
	public void calculateArea(Shape s) {
		s.calculateArea();
	}

	public static void main(String[] args) {
		Geometry g = new Geometry();
		
		Rectangle r = new Rectangle(2, 4);
		g.displayName(r);
		g.calculateArea(r);
		
		Circle c = new Circle(2);
		g.displayName(c);
		g.calculateArea(c);

	}

}
