package DemoShape;

public class Rectangle extends Shape {
	double l;
	double b;

	public Rectangle(double l, double b) {
		super("Rectangle");
		this.l = l;
		this.b = b;
	}

	public void calculateArea() {
		System.out.println("Area of Rectangle: " + l * b);
	}

}
