package Shub8;

public interface NumberFilter {

		
	}
	
	
	

}
