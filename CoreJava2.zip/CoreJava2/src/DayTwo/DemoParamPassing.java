package DayTwo;

public class DemoParamPassing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
