package DayTwo;
import DayOne.Date;
public class Maths{
	public static void swap(int i, int j) {
		int temp=0;
		temp=i;
		i=j;
		j=temp;
		System.out.println("After swap : "+i +"j: "+j);
	}
	
}


