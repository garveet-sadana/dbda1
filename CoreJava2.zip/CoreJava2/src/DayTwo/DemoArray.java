package DayTwo;

public class DemoArray {

	public static void main(String[] args) {
		 int arr1[]= {23,67,54,89,76};
		 for(int i=0; i<arr1.length;i++) {
			 System.out.println(arr1[i]);
		 }
		 Book [] books = new Book[2];
		 books[0]= new Book();
		 books[0].setIsbn(12000);
		 books[0].setTitle("Head First Java");
		 
		 books[1]= new Book();
		 books[1].setIsbn(67000);
		 books[1].setTitle("Head 2 Java");
		 
		 for(int i=0; i<books.length;i++) {
			 System.out.println(books[i]);
		 }
		 
		 Book [] bk= {new Book(678945,"eee"),
				 new Book(2345,"bbbb")};
		 
		 for(Book b:bk) {
			 System.out.println(b.getIsbn());
		 }
		 int a[] = {10};
		 int b[] = {20};
		 System.out.println("Before swap a: "+a[0]+",b: "+b[0]);
		 Book.swap(a,b);
		 System.out.println("after swap a: "+a[0]+",b: "+b[0]);
		 int k=10;
		 System.out.println("Before increment k is "+k);
		 Book.increment(k);
		 System.out.println("after increment k is "+k);
		 
		 
		 
	}

}
