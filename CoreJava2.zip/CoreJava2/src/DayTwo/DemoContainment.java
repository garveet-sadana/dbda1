package DayTwo;

import DayOne.Date;

public class DemoContainment {
	public static void main(String[] args) {
		Employee e1=new Employee();
		System.out.println(e1);
		Employee e2= new Employee(200,"ghj",new Date(12,"Dec",2021));
		System.out.println(e2);
	}

}
