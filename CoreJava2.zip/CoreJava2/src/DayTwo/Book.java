package DayTwo;

public class Book {
	private int isbn;
	private String title;
	public Book() {
		
	}
	public Book(int isbn, String title) {
		this.isbn=isbn;
		this.title=title;
		
	}
	public void setIsbn(int isbn) {
		this.isbn=isbn;
		
	}
	public void setTitle(String title) {
		this.title=title;
	}
	public int getIsbn() {
		return isbn;
		
	}
	public String getTitle() {
		return title;
		
	}
	public String toString() {
		return "Book isbn: "+isbn+ "Title: "+title;
	}
	
	public static void swap(int [] i, int [] j) {
		int temp=0;
		 temp=i[0];
		 i[0]=j[0];
		 j[0]=temp;
	}
	public static void increment(int a) {
		a++;
	}

}
