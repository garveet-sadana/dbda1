package Practice1;

public class ThreadPractice2  {
	public static void main(String[] args) throws Exception{
		Thread t3 = new Thread(new Runnable() {
			public void run() {
				for (int i = 0; i < 5; i++) {
					System.out.println("Hi");
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
				}

			}
		},"t3");
		Thread t4 = new Thread(new Runnable() {
			public void run() {
				for(int i=0 ; i<5 ; i++) {
					System.out.println("Hello");
					try {Thread.sleep(1000);}catch(InterruptedException e) {}
				}
				
			}
			
		},"t4");
		System.out.println(t3.getName());
		System.out.println(t4.getName());
		System.out.println(t4.getPriority());
		System.out.println(t3.getPriority());
		t3.start();
		try {Thread.sleep(100);}catch(InterruptedException e) {}
		t4.start();
		
		t3.join();
		t4.join();
		
		System.out.println(t3.isAlive());
		System.out.println("bye");

	}
}
