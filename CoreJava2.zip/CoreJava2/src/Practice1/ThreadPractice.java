package Practice1;

public class ThreadPractice {

	public static void main(String[] args) {

		Thread t1 = new Thread(new Runnable() {
			public void run() {
				for (int i = 0; i < 10; i++) {
					System.out.println("Hi");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}

				}

			}
		});
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				for (int i = 0; i < 10; i++) {
					System.out.println("hello");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
				}
			}
		});
		t1.start();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
		}
		t2.start();
	}

}
