package Practice1;

class Q {
	int num;
	boolean flag = false;
	public synchronized void put(int num) {
		while(flag) {
			try { wait();}catch(InterruptedException e) {}
		}
		System.out.println("put :"+num);
		this.num = num;
		flag = true;
		notify();
	}

	public synchronized void get() {
		while(!flag) {
			try {wait();} catch(InterruptedException e) {}
		}
		System.out.println("get :"+num);
		flag = false;
		notify();
	}
}

class Producer implements Runnable {
	Q q;
	
	
	public Producer(Q q) {
		Thread t1 = new Thread(this,"Producer");
		t1.start();
		this.q = q;
	}

	public void run() {
		int i =0;
		while (true) {
			q.put(i++);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}

		}
	}
}
class consumer implements Runnable{
	Q q;
	public consumer(Q q ) {
		this.q =q;
		Thread t2 = new Thread(this,"Producer");
		t2.start();
	}
	public void run() {
		
		while(true) {
			q.get();
			try { 
				Thread.sleep(1000);
			} catch (InterruptedException e) {}
		}
		
	}
}



public class InterThread {
	public static void main(String[] args) {
		Q q = new Q();
		new Producer(q);
		new consumer(q);
	}
}
