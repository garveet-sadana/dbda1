package Practice1;
class  Counter{
	int count;
	public synchronized void increment() {
		count++;
		System.out.println(Thread.currentThread().getName());
	}
}
public class SynchroDemo  {
	public static void main(String[] args) throws Exception{
		Counter c = new Counter();
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				for(int i = 0; i<10;i++) {
					c.increment();
					
				}
				
			}
			
		},"first");
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				for(int i = 0; i<5;i++) {
					c.increment();
					
				}
			}
			
			
		},"second");
		
		
		
		
		t1.start();
		t2.start();
		
		t1.join();
		System.out.println("Count "+c.count);
		t2.join();
		System.out.println("Count "+c.count);
	}
}
