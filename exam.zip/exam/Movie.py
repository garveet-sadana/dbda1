def add_movie(movies):
    title = input("Enter movie title: ")
    genre = input("Enter movie genre: ")
    year = input("Enter movie release year: ")
    movies.append((title, genre, year))

def display_movies(movies):
    for movie in movies:
        print(f"Title: {movie[0]}, Genre: {movie[1]}, Year: {movie[2]}")

def search_movie_by_title(movies):
    title = input("Enter movie title to search: ")
    for movie in movies:
        if movie[0].lower() == title.lower():
            print(f"Found - Title: {movie[0]}, Genre: {movie[1]}, Year: {movie[2]}")
            return
    print("Movie not found.")

def remove_movie(movies):
    title = input("Enter title of the movie to remove: ")
    for movie in movies:
        if movie[0].lower() == title.lower():
            movies.remove(movie)
            print("Movie removed successfully.")
            return
    print("Movie not found.")

def main():
    movies = []
    while True:
        print("\nMenu:")
        print("1. Add a movie")
        print("2. Display all movies")
        print("3. Search for a movie by title")
        print("4. Remove a movie by title")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            add_movie(movies)
        elif choice == '2':
            display_movies(movies)
        elif choice == '3':
            search_movie_by_title(movies)
        elif choice == '4':
            remove_movie(movies)
        elif choice == '5':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
