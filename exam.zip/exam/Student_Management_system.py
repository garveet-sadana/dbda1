def add_student(students):
    student_id = input("Enter student ID: ")
    name = input("Enter student name: ")
    marks = [float(input(f"Enter marks for subject {i + 1}: ")) for i in range(3)]
    students.append((student_id, name, marks))

def display_students(students):
    for student in students:
        print(f"ID: {student[0]}, Name: {student[1]}, Marks: {student[2]}")

def search_by_id(students):
    student_id = input("Enter student ID to search: ")
    for student in students:
        if student[0] == student_id:
            print(f"ID: {student[0]}, Name: {student[1]}, Marks: {student[2]}")
            return
    print("Student not found.")

def search_by_name(students):
    name = input("Enter student name to search: ")
    found = False
    for student in students:
        if student[1].lower() == name.lower():
            print(f"ID: {student[0]}, Name: {student[1]}, Marks: {student[2]}")
            found = True
    if not found:
        print("Student not found.")

def main():
    students = []
    while True:
        print("\nMenu:")
        print("1. Add a student")
        print("2. Display all students")
        print("3. Search by ID")
        print("4. Search by name")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            add_student(students)
        elif choice == '2':
            display_students(students)
        elif choice == '3':
            search_by_id(students)
        elif choice == '4':
            search_by_name(students)
        elif choice == '5':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
