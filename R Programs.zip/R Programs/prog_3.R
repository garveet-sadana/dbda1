### for loop
for (i in 1:5){
  print(i)
}
s <- c(4,7,89,23,12,0)
for (i in s){
  print(i*i)
}

# C like way
for (i in 1:6){
  print(s[i]*s[i])
}
### while loop
cnt <- 1
while(cnt <= 5){
  print(cnt)
  cnt <- cnt + 1
}

## break
cnt <- 1
while(cnt <= 5){
  if (cnt==3) break
  print(cnt)
  cnt <- cnt + 1
}

## next: skipping an interation

for ( i in 1:5 ){
  if (i == 3) next
  print(i)
}

## seq
seq(1,20)
seq(1,20, 3)
seq(20, 1, -2)

## log
s <- c(4,5,0,3,18,13,0)
log(s)
log1p(s) # log(1+x)

d <- c(1200003, 7800000, 45099998, 2698765, 4)
log(d)

### exp
exp(1)
exp(3)
n <- log(9)
exp(n)

### ifelse
v <- c(34, 12, 9, 25, 36, 2, 29, 16)
res <- ifelse(v <= 16, "Fail", "Pass")
res

### Aggregate Functions
data("airquality")
names(airquality)
# Examining the missing values
sum( is.na( airquality$Ozone ) )
sum( is.na( airquality$Solar.R ) )
sum( is.na( airquality$Wind ) )
sum( is.na( airquality$Temp ) )
sum( is.na( airquality$Month ) )
sum( is.na( airquality$Day ) )

mean(airquality$Wind)
mean(airquality$Ozone)
mean(airquality$Ozone, na.rm = T) # ignoring NAs
mean(airquality$Solar.R, na.rm = T)

summary(airquality$Ozone)

### attach
attach(airquality)
mean(Wind)
mean(Ozone, na.rm = T)
detach(airquality)
mean(Wind) # won't work

#### 
g <- function(x){
  return(3*x + 5)
}
g(2)
g(6)

h <- function(x){
  return(4*(x**2) + 3*x + 2)
}
h(1)


####


cel_fah <- function(cel){
  return(cel*1.8 + 32)
}

tempC <- readline("Enter the temp in celcius:")
tempC <- as.numeric(tempC)
cel_fah(tempC)

mu <- mean(airquality$Ozone, na.rm = T)
std <- sd(airquality$Ozone, na.rm = T)
s <- list(avg=mu,std_dev=std)

mu_std <- function(col_name){
  mu <- mean(col_name, na.rm = T)
  std <- sd(col_name, na.rm = T)
  s <- list(avg=mu,std_dev=std)
  return(s)
}
ans <- mu_std(airquality$Solar.R)
paste("Mean:", ans$avg)
paste("Std dev:", ans$std_dev)
