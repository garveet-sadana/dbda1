library(tidyverse)

data("table4a")
### Gathering
## gather
gather(table4a, `1999`, `2000`, key = "year", value = "val")
#or
table4a %>% gather(`1999`, `2000`, key = "year", value = "val")
#or
table4a %>% gather(-country, key = "year", value = "val")

## pivot_longer
table4a %>% 
  pivot_longer(-country, names_to = "year",
               values_to = "val")

### Spreading
table2
## spread
table2 %>% 
  spread(key = "type", value = "count")

## pivot_wider
table2 %>% 
  pivot_wider(names_from = "type", 
              values_from = "count")

### Separate
table3
table3 %>% 
  separate(rate, into = c("count",'pop'),
           convert = T)

### Unite
table5
table5 %>% 
  unite(yr, century, year)

table5 %>% 
  unite(yr, century, year, sep = "")

#### Ex 1
comb1 <- read.csv("comb1.csv",stringsAsFactors = T)

comb1 %>% 
  pivot_longer(-District, names_to = "ItemType",
               values_to = "qty")

### Ex 2
comb2 <- read.csv("comb2.csv")
comb2 %>% 
  separate(PatientID, 
           into = c('projectID','SiteID','PatientNumber'))
