a <- c(34, 78, 30, 45)
barplot(a)

pie(a)

b <- c(109, 45, 49, 50)
rb <- rbind(a,b)
barplot(rb)
barplot(rb, beside = T)
barplot(rb, beside = T, col = c("violetred","thistle2"))
colors()

setwd("C:/R/Datasets/")
cars93 <- read.csv("cars93.csv", stringsAsFactors = T)
table(cars93$Type)
barplot(table(cars93$Type), beside = T,
        main = "Types of Cars",
        xlab = "Types", ylab = "Count")

######## Histogram
hist(cars93$Price)

###### Scatter Plot
plot(cars93$MPG.city, cars93$Price)
plot(cars93$MPG.city, cars93$Price, pch=17,
     col="violetred", xlab = "Milage",
     ylab = "Price", main = "Scatter Plot")

###### Boxplot
boxplot(cars93$MPG.city)

boxplot(cars93$MPG.city ~ cars93$Type,
        xlab = "Type", ylab = "Milage",
        main="Boxplot")

##### Line graph
data("AirPassengers")
plot(AirPassengers)

#### Density Plot
plot(density(cars93$Price))
