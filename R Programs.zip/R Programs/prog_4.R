library(tidyverse)
data("mtcars")
class(mtcars)
tbl_mtcars <- as_tibble(mtcars)
class(tbl_mtcars)


setwd("C:/R/Datasets/")

### Arrange the data
b <- read.csv("Datasets\\B.csv")
arrange(b, B)

cars93 <- read.csv("Datasets\\Cars93.csv", stringsAsFactors = T)
s_cars <- arrange(cars93, Price)
s_cars
view((s_cars))
s_cars <- arrange(cars93, Type, Price)
s_cars <- arrange(cars93, Type, desc(Price))

### Select
s_cars <- select(cars93, 1:4)
s_cars <- select(cars93, Model:Price)
s_cars <- select(cars93, starts_with("MPG"))
s_cars <- select(cars93, contains("in"))
names(s_cars)

### Filter
s_cars <- filter(cars93, Type=="Small")
s_cars <- filter(cars93, Type=="Small" & Price<20)

## Rename
df <- read.csv("Lab_Uric.csv")
df_1 <- rename(df, "PID"="PatientID")

## mutate
data("cars")
cars <- mutate(cars, time=dist/speed)
cars

data("txhousing")
txhousing <- mutate(txhousing, r1=sales/volume, r2=median/volume)

#or creating columns separately in assignment statements
data("txhousing")
txhousing$r1 <- txhousing$sales/txhousing$volume
txhousing$r2 <- txhousing$median/txhousing$volume

## summary: not a part of dplyr
summary(txhousing$sales)

## summarise
summarize(txhousing, avg_sales=mean(sales, na.rm=T),
                     std_sales=sd(sales, na.rm=T))

summarize(txhousing, avg_sales=mean(sales, na.rm=T),
          std_sales=sd(sales, na.rm=T),
          avg_vol=mean(volume, na.rm=T),
          std_vol=sd(volume, na.rm=T))

## group by
grp_hous <- group_by(txhousing, year)
summarize(grp_hous, avg_sales=mean(sales, na.rm=T))


grp_hous <- group_by(txhousing, city, year)
summarize(grp_hous, avg_sales=mean(sales, na.rm=T))

## magritrr
# %>% shortcut key: ctrl shift m
txhousing %>% 
  group_by(year) %>% 
  summarise(avg_sales=mean(sales, na.rm=T))

select(cars93, Model:Price)
cars93 %>% 
  select(Model:Price)

### filter the cars93 with only Type=Midsize and then
### on that dataset calculate mean price groupby AirBags
cars93 %>% 
  filter(Type=="Midsize") %>% 
  group_by(AirBags) %>% 
  summarise(avg_price = mean(Price, na.rm = T))

#### join
items <- read.csv("Items.csv")
ord_det <- read.csv("Ord_Details.csv")
item_ord <- inner_join(items, ord_det, by = "Item.ID")

