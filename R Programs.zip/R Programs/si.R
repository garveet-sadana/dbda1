p <- 10000
n <- 3
r <- 9
si <- p*n*r/100
print(si)