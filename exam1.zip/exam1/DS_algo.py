def reverse_list(lst):
    return lst[::-1]

# Example usage
print(reverse_list([1, 2, 3, 4, 5]))

#----------------------------------------
def find_max_min(lst):
    return max(lst), min(lst)

# Example usage
print(find_max_min([3, 1, 4, 1, 5, 9]))

def sum_of_elements(lst):
    return sum(lst)

# Example usage
print(sum_of_elements([1, 2, 3, 4, 5]))

def count_occurrences(lst, value):
    return lst.count(value)

# Example usage
print(count_occurrences([1, 2, 2, 3, 4, 2], 2))

def remove_duplicates(lst):
    return list(set(lst))

# Example usage
print(remove_duplicates([1, 2, 2, 3, 4, 4, 5]))

def list_intersection(lst1, lst2):
    return list(set(lst1) & set(lst2))

# Example usage
print(list_intersection([1, 2, 3], [2, 3, 4]))


def list_union(lst1, lst2):
    return list(set(lst1) | set(lst2))

# Example usage
print(list_union([1, 2, 3], [2, 3, 4]))


def bubble_sort(lst):
    for i in range(len(lst)):
        for j in range(0, len(lst) - i - 1):
            if lst[j] > lst[j + 1]:
                lst[j], lst[j + 1] = lst[j + 1], lst[j]
    return lst

# Example usage
print(bubble_sort([64, 34, 25, 12, 22, 11, 90]))


def binary_search(lst, target):
    left, right = 0, len(lst) - 1
    while left <= right:
        mid = (left + right) // 2
        if lst[mid] == target:
            return mid
        elif lst[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1

# Example usage
print(binary_search([1, 2, 3, 4, 5], 3))



def rotate_list(lst, k):
    k = k % len(lst)  # Handle rotations greater than the list length
    return lst[-k:] + lst[:-k]

# Example usage
print(rotate_list([1, 2, 3, 4, 5], 2))


def merge_sorted_lists(lst1, lst2):
    return sorted(lst1 + lst2)

# Example usage
print(merge_sorted_lists([1, 3, 5], [2, 4, 6]))


def second_largest(lst):
    unique_lst = list(set(lst))
    unique_lst.sort()
    return unique_lst[-2] if len(unique_lst) >= 2 else None

# Example usage
print(second_largest([1, 2, 3, 4, 5]))


def find_missing_number(lst, n):
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(lst)
    return expected_sum - actual_sum

# Example usage
print(find_missing_number([1, 2, 4, 5], 5))


from collections import defaultdict

def group_anagrams(words):
    anagrams = defaultdict(list)
    for word in words:
        sorted_word = ''.join(sorted(word))
        anagrams[sorted_word].append(word)
    return list(anagrams.values())

# Example usage
print(group_anagrams(["eat", "tea", "tan", "ate", "nat", "bat"]))


def product_of_elements(lst):
    product = 1
    for num in lst:
        product *= num
    return product

# Example usage
print(product_of_elements([1, 2, 3, 4]))


def fibonacci(n):
    fib_list = [0, 1]
    for i in range(2, n):
        fib_list.append(fib_list[-1] + fib_list[-2])
    return fib_list[:n]

# Example usage
print(fibonacci(10))



from collections import Counter

def sort_by_frequency(lst):
    frequency = Counter(lst)
    return sorted(lst, key=lambda x: (-frequency[x], lst.index(x)))

# Example usage
print(sort_by_frequency([1, 1, 2, 2, 2, 3, 3, 4]))


def find_pairs_with_sum(lst, target):
    pairs = []
    seen = set()
    for num in lst:
        complement = target - num
        if complement in seen:
            pairs.append((complement, num))
        seen.add(num)
    return pairs

# Example usage
print(find_pairs_with_sum([1, 2, 3, 4, 5], 5))

#-------------------------------------------------------Class and Object--------------------------------------------------------------------------
from collections import defaultdict, Counter


class ListOperations:
    def __init__(self, lst):
        self.lst = lst

    def reverse_list(self):
        return self.lst[::-1]

    def find_max_min(self):
        return max(self.lst), min(self.lst)

    def sum_of_elements(self):
        return sum(self.lst)

    def count_occurrences(self, value):
        return self.lst.count(value)

    def remove_duplicates(self):
        return list(set(self.lst))

    def list_intersection(self, lst2):
        return list(set(self.lst) & set(lst2))

    def list_union(self, lst2):
        return list(set(self.lst) | set(lst2))

    def bubble_sort(self):
        lst = self.lst[:]
        for i in range(len(lst)):
            for j in range(0, len(lst) - i - 1):
                if lst[j] > lst[j + 1]:
                    lst[j], lst[j + 1] = lst[j + 1], lst[j]
        return lst

    def binary_search(self, target):
        left, right = 0, len(self.lst) - 1
        while left <= right:
            mid = (left + right) // 2
            if self.lst[mid] == target:
                return mid
            elif self.lst[mid] < target:
                left = mid + 1
            else:
                right = mid - 1
        return -1

    def rotate_list(self, k):
        k = k % len(self.lst)
        return self.lst[-k:] + self.lst[:-k]

    def merge_sorted_lists(self, lst2):
        return sorted(self.lst + lst2)

    def second_largest(self):
        unique_lst = list(set(self.lst))
        unique_lst.sort()
        return unique_lst[-2] if len(unique_lst) >= 2 else None

    def find_missing_number(self, n):
        expected_sum = n * (n + 1) // 2
        actual_sum = sum(self.lst)
        return expected_sum - actual_sum

    def group_anagrams(self, words):
        anagrams = defaultdict(list)
        for word in words:
            sorted_word = ''.join(sorted(word))
            anagrams[sorted_word].append(word)
        return list(anagrams.values())

    def product_of_elements(self):
        product = 1
        for num in self.lst:
            product *= num
        return product

    def fibonacci(self, n):
        fib_list = [0, 1]
        for i in range(2, n):
            fib_list.append(fib_list[-1] + fib_list[-2])
        return fib_list[:n]

    def sort_by_frequency(self):
        frequency = Counter(self.lst)
        return sorted(self.lst, key=lambda x: (-frequency[x], self.lst.index(x)))

    def find_pairs_with_sum(self, target):
        pairs = []
        seen = set()
        for num in self.lst:
            complement = target - num
            if complement in seen:
                pairs.append((complement, num))
            seen.add(num)
        return pairs


# Example usage:

# Creating an object of ListOperations class
lst_ops = ListOperations([1, 2, 3, 4, 5])

# Example method calls
print(lst_ops.reverse_list())  # [5, 4, 3, 2, 1]
print(lst_ops.find_max_min())  # (5, 1)
print(lst_ops.sum_of_elements())  # 15
print(lst_ops.count_occurrences(2))  # 1
print(lst_ops.remove_duplicates())  # [1, 2, 3, 4, 5]
print(lst_ops.list_intersection([2, 3, 4]))  # [2, 3, 4]
print(lst_ops.list_union([2, 3, 4]))  # [1, 2, 3, 4, 5]
print(lst_ops.bubble_sort())  # [1, 2, 3, 4, 5]
print(lst_ops.binary_search(3))  # 2
print(lst_ops.rotate_list(2))  # [4, 5, 1, 2, 3]
print(lst_ops.merge_sorted_lists([0, 6]))  # [0, 1, 2, 3, 4, 5, 6]
print(lst_ops.second_largest())  # 4
print(lst_ops.find_missing_number(5))  # 3
print(lst_ops.product_of_elements())  # 120
print(lst_ops.fibonacci(10))  # [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
print(lst_ops.sort_by_frequency())  # [2, 2, 2, 1, 1, 3, 3, 4]
print(lst_ops.find_pairs_with_sum(5))  # [(2, 3), (1, 4)]


