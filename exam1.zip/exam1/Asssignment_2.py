# Question - 1  Write a Program which accepts a string from the console and print the
# characters that have even indexes if the Character is an alphabet. Concatenate
# the characters and print.

def even_indexed_alphabets():
    # Accept a string from the user
    input_string = input("Enter a string: ")

    # Initialize an empty string to store characters at even indexes
    result = ""

    # Loop through the string
    for index in range(len(input_string)):
        # Check if the index is even and the character is an alphabet
        if index % 2 == 0 and input_string[index].isalpha():
            result += input_string[index]

    # Print the concatenated result
    print(f"Characters at even indexes that are alphabets: {result}")

# Run the function
even_indexed_alphabets()



#----------------------------------------------------------------------------------------
#Count Character

def count_characters():
    # Accept a string from the user
    input_string = input("Enter a string: ")

    # Create a dictionary to hold character counts
    character_count = {}

    # Loop through each character in the string
    for char in input_string:
        # If the character is already in the dictionary, increment its count
        if char in character_count:
            character_count[char] += 1
        else:
            # Otherwise, add it to the dictionary with a count of 1
            character_count[char] = 1

    # Print the character counts
    print("Character counts:")
    for char, count in character_count.items():
        print(f"'{char}': {count}")


# Run the function
count_characters()

