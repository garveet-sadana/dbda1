def add_book(books):
    title = input("Enter book title: ")
    author = input("Enter book author: ")
    isbn = input("Enter book ISBN: ")
    books.append((title, author, isbn))

def display_books(books):
    for book in books:
        print(f"Title: {book[0]}, Author: {book[1]}, ISBN: {book[2]}")

def search_by_title(books):
    title = input("Enter book title to search: ")
    for book in books:
        if book[0].lower() == title.lower():
            print(f"Found - Title: {book[0]}, Author: {book[1]}, ISBN: {book[2]}")
            return
    print("Book not found.")

def remove_book(books):
    isbn = input("Enter ISBN of the book to remove: ")
    for book in books:
        if book[2] == isbn:
            books.remove(book)
            print("Book removed successfully.")
            return
    print("Book not found.")

def main():
    books = []
    while True:
        print("\nMenu:")
        print("1. Add a book")
        print("2. Display all books")
        print("3. Search for a book by title")
        print("4. Remove a book by ISBN")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            add_book(books)
        elif choice == '2':
            display_books(books)
        elif choice == '3':
            search_by_title(books)
        elif choice == '4':
            remove_book(books)
        elif choice == '5':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
