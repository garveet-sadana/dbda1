# Q. Find the largest and smallest number in the list which taken as input from user
# using list operations.

def find_largest_and_smallest():

    input_numbers = input("Enter numbers separated by spaces: ")

    numbers = list(map(float, input_numbers.split()))

    if not numbers:  # Check if the list is empty
        print("No numbers entered.")
        return

    # Initialize largest and smallest with the first element of the list
    largest = numbers[0]
    smallest = numbers[0]

    # Iterate through the list to find the largest and smallest numbers
    for number in numbers:
        # Update largest if the current number is greater
        if number > largest:
            largest = number
        # Update smallest if the current number is smaller
        if number < smallest:
            smallest = number

    # Display the results
    print(f"The largest number is: {largest}")
    print(f"The smallest number is: {smallest}")


# Run the function
find_largest_and_smallest()


#------------------------------------------------------------------------------------------
# Write a menu driven program to maintain student information. for every student store studetid,
# sname, and m1,m2,m3 marks for 3 subject:
# [+] Create a list to store Multiple students.
# 1. Display All Student
# 2. Search by id
# 3. Search by name
# 4. Exit

def display_students(students):
    if not students:
        print("No students found.")
        return
    print("\nStudent Information:")
    print("{:<10} {:<20} {:<5} {:<5} {:<5}".format("Student ID", "Name", "M1", "M2", "M3"))
    for student in students:
        print("{:<10} {:<20} {:<5} {:<5} {:<5}".format(student['student_id'], student['name'], student['marks'][0],
                                                       student['marks'][1], student['marks'][2]))


def search_by_id(students, student_id):
    for student in students:
        if student['student_id'] == student_id:
            print("\nStudent Found:")
            print("{:<10} {:<20} {:<5} {:<5} {:<5}".format(student['student_id'], student['name'], student['marks'][0],
                                                           student['marks'][1], student['marks'][2]))
            return
    print("Student ID not found.")


def search_by_name(students, name):
    found = False
    for student in students:
        if student['name'].lower() == name.lower():
            print("\nStudent Found:")
            print("{:<10} {:<20} {:<5} {:<5} {:<5}".format(student['student_id'], student['name'], student['marks'][0],
                                                           student['marks'][1], student['marks'][2]))
            found = True
    if not found:
        print("Student name not found.")


def main():
    students = []

    while True:
        print("\nMenu:")
        print("1. Add Student")
        print("2. Display All Students")
        print("3. Search by ID")
        print("4. Search by Name")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            # Add a new student
            student_id = input("Enter Student ID: ")
            name = input("Enter Student Name: ")
            marks = []
            for i in range(1, 4):
                mark = float(input(f"Enter marks for subject {i}: "))
                marks.append(mark)
            students.append({'student_id': student_id, 'name': name, 'marks': marks})
            print("Student added successfully.")

        elif choice == '2':
            # Display all students
            display_students(students)

        elif choice == '3':
            # Search by ID
            student_id = input("Enter Student ID to search: ")
            search_by_id(students, student_id)

        elif choice == '4':
            # Search by name
            name = input("Enter Student Name to search: ")
            search_by_name(students, name)

        elif choice == '5':
            # Exit
            print("Exiting the program.")
            break

        else:
            print("Invalid choice. Please try again.")


# Run the program
main()


#Set
def find_repeated_items(input_tuple):
    seen = set()          # Set to keep track of seen items
    repeated = set()      # Set to store repeated items

    # Iterate through each item in the tuple
    for item in input_tuple:
        if item in seen:
            repeated.add(item)  # Add to repeated set if already seen
        else:
            seen.add(item)      # Add item to seen set if not seen yet

    return repeated

# Sample input
sample = (1, 2, 3, 4, 3, 2, 4, 6, 7, 8, 6, 4, 3, 2)

# Find and print repeated items
repeated = find_repeated_items(sample)
print("Repeated items:", repeated)


