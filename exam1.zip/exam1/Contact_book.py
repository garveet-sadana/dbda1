def add_contact(contacts):
    name = input("Enter contact name: ")
    phone = input("Enter contact phone number: ")
    contacts.append((name, phone))
    print(f"Contact '{name}' added.")

def display_contacts(contacts):
    if contacts:
        for contact in contacts:
            print(f"Name: {contact[0]}, Phone: {contact[1]}")
    else:
        print("No contacts available.")

def search_contact_by_name(contacts):
    name = input("Enter contact name to search: ")
    for contact in contacts:
        if contact[0].lower() == name.lower():
            print(f"Found - Name: {contact[0]}, Phone: {contact[1]}")
            return
    print("Contact not found.")

def remove_contact(contacts):
    name = input("Enter contact name to remove: ")
    for contact in contacts:
        if contact[0].lower() == name.lower():
            contacts.remove(contact)
            print(f"Contact '{name}' removed.")
            return
    print("Contact not found.")

def main():
    contacts = []
    while True:
        print("\nMenu:")
        print("1. Add a contact")
        print("2. Display all contacts")
        print("3. Search for a contact by name")
        print("4. Remove a contact by name")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            add_contact(contacts)
        elif choice == '2':
            display_contacts(contacts)
        elif choice == '3':
            search_contact_by_name(contacts)
        elif choice == '4':
            remove_contact(contacts)
        elif choice == '5':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
