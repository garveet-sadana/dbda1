def add_task(tasks):
    description = input("Enter task description: ")
    priority = input("Enter task priority: ")
    tasks.append((description, priority))

def display_tasks(tasks):
    if tasks:
        for idx, task in enumerate(tasks):
            print(f"{idx + 1}. Description: {task[0]}, Priority: {task[1]}")
    else:
        print("No tasks available.")

def mark_task_completed(tasks):
    display_tasks(tasks)
    task_num = int(input("Enter the task number to mark as completed: ")) - 1
    if 0 <= task_num < len(tasks):
        tasks.pop(task_num)
        print("Task marked as completed.")
    else:
        print("Invalid task number.")

def remove_task(tasks):
    display_tasks(tasks)
    task_num = int(input("Enter the task number to remove: ")) - 1
    if 0 <= task_num < len(tasks):
        tasks.pop(task_num)
        print("Task removed successfully.")
    else:
        print("Invalid task number.")

def main():
    tasks = []
    while True:
        print("\nMenu:")
        print("1. Add a task")
        print("2. Display all tasks")
        print("3. Mark a task as completed")
        print("4. Remove a task")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            add_task(tasks)
        elif choice == '2':
            display_tasks(tasks)
        elif choice == '3':
            mark_task_completed(tasks)
        elif choice == '4':
            remove_task(tasks)
        elif choice == '5':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()

