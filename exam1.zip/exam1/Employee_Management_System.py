def add_employee(employees):
    emp_id = input("Enter employee ID: ")
    name = input("Enter employee name: ")
    salary = float(input("Enter employee salary: "))
    employees.append((emp_id, name, salary))

def display_employees(employees):
    for employee in employees:
        print(f"ID: {employee[0]}, Name: {employee[1]}, Salary: {employee[2]}")

def search_by_id(employees):
    emp_id = input("Enter employee ID to search: ")
    for employee in employees:
        if employee[0] == emp_id:
            print(f"ID: {employee[0]}, Name: {employee[1]}, Salary: {employee[2]}")
            return
    print("Employee not found.")

def update_salary(employees):
    emp_id = input("Enter employee ID to update salary: ")
    for employee in employees:
        if employee[0] == emp_id:
            new_salary = float(input("Enter new salary: "))
            employee[2] = new_salary
            print("Salary updated successfully.")
            return
    print("Employee not found.")

def main():
    employees = []
    while True:
        print("\nMenu:")
        print("1. Add an employee")
        print("2. Display all employees")
        print("3. Search for an employee by ID")
        print("4. Update an employee's salary by ID")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            add_employee(employees)
        elif choice == '2':
            display_employees(employees)
        elif choice == '3':
            search_by_id(employees)
        elif choice == '4':
            update_salary(employees)
        elif choice == '5':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
